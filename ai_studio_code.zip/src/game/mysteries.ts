import type { MysteryChapterDef, RuneSymbolId, SaveData } from './types';

export interface RuneMeta {
  id: RuneSymbolId;
  name: string;
  glyph: string;
  colorHex: number;
  cssColor: string;
}

export const RUNE_META: Record<RuneSymbolId, RuneMeta> = {
  sun: {
    id: 'sun',
    name: 'Sun',
    glyph: '☉',
    colorHex: 0xffcf40,
    cssColor: '#ffcf40',
  },
  jaguar: {
    id: 'jaguar',
    name: 'Jaguar',
    glyph: '◈',
    colorHex: 0xff7b38,
    cssColor: '#ff7b38',
  },
  serpent: {
    id: 'serpent',
    name: 'Serpent',
    glyph: '☽',
    colorHex: 0x2df2a6,
    cssColor: '#2df2a6',
  },
  lotus: {
    id: 'lotus',
    name: 'Lotus',
    glyph: '✦',
    colorHex: 0x62d9ff,
    cssColor: '#62d9ff',
  },
};

export const RUNE_ORDER: RuneSymbolId[] = ['sun', 'jaguar', 'serpent', 'lotus'];

export const MYSTERY_CHAPTERS: MysteryChapterDef[] = [
  {
    id: 'mystery-ch1-sundial',
    chapterNumber: 1,
    title: 'The Sun-Dial Gate',
    difficultyLabel: 'Initiate',
    riddleClue:
      'First awaken the Dawn (Sun), then step through the Blooming Water (Lotus).',
    sequence: ['sun', 'lotus'],
    loreTitle: 'Tablet I: Founding of the Canopy Road',
    loreText:
      'Before the rivers flooded the valley, the Canopy Wardens carved twin beacons of gold and azure so travelers could find the hidden bridges.',
    rewardCoins: 90,
    rewardRelics: 1,
  },
  {
    id: 'mystery-ch2-obelisk',
    chapterNumber: 2,
    title: 'Whisper of the Sunken Obelisk',
    difficultyLabel: 'Adept',
    riddleClue:
      'Follow the Jade River (Serpent), leap with the Stalker (Jaguar), and face the Noon Zenith (Sun).',
    sequence: ['serpent', 'jaguar', 'sun'],
    loreTitle: 'Tablet II: The Sunken Causeway',
    loreText:
      'When the monsoon altars sank, priests sealed the lower sluices behind a three-glyph chime tuned to the roar of the waterfalls.',
    rewardCoins: 160,
    rewardRelics: 2,
    unlocksBiome: 'sunken-temple',
  },
  {
    id: 'mystery-ch3-crystal',
    chapterNumber: 3,
    title: 'Echoes of the Crystal Vault',
    difficultyLabel: 'Scholar',
    riddleClue:
      'Begin at the Quiet Bloom (Lotus), wind past the Serpent, strike as the Jaguar, and bow to the Bloom again (Lotus).',
    sequence: ['lotus', 'serpent', 'jaguar', 'lotus'],
    loreTitle: 'Tablet III: Beneath the Roots',
    loreText:
      'The Underground City was lit not by torches, but by living crystal veins that sang whenever explorers echoed the four-part harmony.',
    rewardCoins: 240,
    rewardRelics: 3,
    unlocksBiome: 'underground-city',
  },
  {
    id: 'mystery-ch4-astral',
    chapterNumber: 4,
    title: 'Astral Cipher of the Lost World',
    difficultyLabel: 'Master',
    riddleClue:
      'Unite all four Guardians in ancient order: Sun, Jaguar, Serpent, Lotus.',
    sequence: ['sun', 'jaguar', 'serpent', 'lotus'],
    loreTitle: 'Tablet IV: The Obsidian Sanctum',
    loreText:
      'At the heart of the Lost World rests the Astral Vault—only runners who unite all four guardian runes at full speed may enter its obsidian sanctum.',
    rewardCoins: 360,
    rewardRelics: 5,
    unlocksBiome: 'lost-world',
  },
];

export function getMysteryChapter(id: string): MysteryChapterDef {
  return MYSTERY_CHAPTERS.find((c) => c.id === id) ?? MYSTERY_CHAPTERS[0];
}

export function isMysteryUnlocked(save: SaveData, chapterId: string): boolean {
  const ch = getMysteryChapter(chapterId);
  if (ch.chapterNumber === 1) return true;
  const prev = MYSTERY_CHAPTERS.find((c) => c.chapterNumber === ch.chapterNumber - 1);
  return prev ? save.solvedMysteries.includes(prev.id) : true;
}

export function advanceCipherStep(
  sequence: RuneSymbolId[],
  currentIndex: number,
  collectedRune: RuneSymbolId
): { nextIndex: number; matched: boolean; completed: boolean; reset: boolean } {
  const expected = sequence[currentIndex];
  if (collectedRune === expected) {
    const nextIndex = currentIndex + 1;
    const completed = nextIndex >= sequence.length;
    return {
      nextIndex: completed ? 0 : nextIndex,
      matched: true,
      completed,
      reset: false,
    };
  }
  // If wrong rune matches sequence[0], restart smoothly at step 1; otherwise reset to 0
  const restartAtOne = collectedRune === sequence[0] ? 1 : 0;
  return {
    nextIndex: restartAtOne,
    matched: false,
    completed: false,
    reset: currentIndex > 0,
  };
}

export function applyMysteryCompletion(
  save: SaveData,
  chapterId: string
): { save: SaveData; firstTimeSolve: boolean; unlockedBiome: string | null } {
  const ch = getMysteryChapter(chapterId);
  const firstTime = !save.solvedMysteries.includes(ch.id);

  const solvedMysteries = firstTime
    ? [...save.solvedMysteries, ch.id]
    : save.solvedMysteries;

  const discoveredLoreIds = save.discoveredLoreIds.includes(ch.id)
    ? save.discoveredLoreIds
    : [...save.discoveredLoreIds, ch.id];

  const unlockedBiomes = [...save.unlockedBiomes];
  let unlockedBiome: string | null = null;
  if (ch.unlocksBiome && !unlockedBiomes.includes(ch.unlocksBiome)) {
    unlockedBiomes.push(ch.unlocksBiome);
    unlockedBiome = ch.unlocksBiome;
  }

  // Auto-advance active mystery to next unsolved chapter if available
  const nextChapter = MYSTERY_CHAPTERS.find((c) => !solvedMysteries.includes(c.id));
  const activeMysteryId = nextChapter ? nextChapter.id : ch.id;

  const coinReward = firstTime ? ch.rewardCoins : Math.round(ch.rewardCoins * 0.35);
  const relicReward = firstTime ? ch.rewardRelics : 1;

  return {
    firstTimeSolve: firstTime,
    unlockedBiome,
    save: {
      ...save,
      totalCoins: save.totalCoins + coinReward,
      totalRelics: save.totalRelics + relicReward,
      solvedMysteries,
      discoveredLoreIds,
      unlockedBiomes,
      activeMysteryId,
    },
  };
}

export function submitCodexDecipher(
  save: SaveData,
  chapterId: string,
  attempt: RuneSymbolId[]
): { ok: boolean; save: SaveData; bonusCoins: number } {
  const ch = getMysteryChapter(chapterId);
  if (save.decipheredLoreIds.includes(chapterId)) {
    return { ok: false, save, bonusCoins: 0 };
  }
  if (attempt.length !== ch.sequence.length) {
    return { ok: false, save, bonusCoins: 0 };
  }
  for (let i = 0; i < ch.sequence.length; i++) {
    if (attempt[i] !== ch.sequence[i]) {
      return { ok: false, save, bonusCoins: 0 };
    }
  }
  const bonusCoins = 60 + ch.chapterNumber * 35;
  const discoveredLoreIds = save.discoveredLoreIds.includes(chapterId)
    ? save.discoveredLoreIds
    : [...save.discoveredLoreIds, chapterId];

  return {
    ok: true,
    bonusCoins,
    save: {
      ...save,
      totalCoins: save.totalCoins + bonusCoins,
      discoveredLoreIds,
      decipheredLoreIds: [...save.decipheredLoreIds, chapterId],
    },
  };
}
