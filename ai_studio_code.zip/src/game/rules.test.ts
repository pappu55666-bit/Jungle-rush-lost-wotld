import test from 'node:test';
import assert from 'node:assert/strict';
import {
  LANE_WIDTH,
  activateCharacterAbility,
  applyObstacleHit,
  calculatePickupScore,
  canWatchRewardedAd,
  checkObstacleCollision,
  claimMissionReward,
  clampLane,
  computeRunSpeed,
  createInitialPlayerState,
  getBiomeForDistance,
  getLaneCenterX,
  grantRewardedAdBonus,
  releaseJumpEarly,
  sanitizeSaveData,
  stepPlayerPhysics,
  triggerJump,
  triggerSlide,
  unlockOrSelectCharacter,
  unlockOrSelectCostume,
  updateMissionProgress,
} from './rules';
import { createDefaultSaveData } from './catalog';

test('lane clamping and center X math', () => {
  assert.equal(clampLane(-4), -1);
  assert.equal(clampLane(4), 1);
  assert.equal(getLaneCenterX(-1), -LANE_WIDTH);
  assert.equal(getLaneCenterX(0), 0);
  assert.equal(getLaneCenterX(1), LANE_WIDTH);
});

test('jump, coyote time, jump cut, and jump buffering work reliably', () => {
  const p = createInitialPlayerState();
  assert.equal(triggerJump(p), true);
  assert.equal(p.grounded, false);
  assert.ok(p.vy > 10);

  // Early release cuts upward velocity
  const vyBeforeCut = p.vy;
  releaseJumpEarly(p);
  assert.ok(p.vy < vyBeforeCut);

  // Coyote time allows jump shortly after leaving ground
  const p2 = createInitialPlayerState();
  p2.grounded = false;
  p2.coyoteTimer = 0.08;
  assert.equal(triggerJump(p2), true);

  // Buffering right before landing executes jump upon touch-down
  const p3 = createInitialPlayerState();
  p3.grounded = false;
  p3.coyoteTimer = 0;
  p3.y = 0.2;
  p3.vy = -10;
  assert.equal(triggerJump(p3), false);
  const step = stepPlayerPhysics(p3, 0.04, 0);
  assert.equal(step.landed, true);
  assert.equal(step.jumpedFromBuffer, true);
  assert.equal(p3.grounded, false);
});

test('sliding avoids high stone arches while standing collides', () => {
  const arch = {
    id: 1,
    kind: 'stone-arch' as const,
    lane: 0,
    z: -10,
    width: 2.0,
    height: 1.5,
    depth: 1.0,
    clearanceBottom: 1.05,
    velocityZ: 0,
    hit: false,
  };

  const p = createInitialPlayerState();
  assert.equal(checkObstacleCollision(p, -10, arch), true);

  triggerSlide(p);
  assert.equal(checkObstacleCollision(p, -10, arch), false);
});

test('jumping clears fallen logs while ground collision hits', () => {
  const log = {
    id: 2,
    kind: 'fallen-log' as const,
    lane: 0,
    z: -15,
    width: 2.1,
    height: 0.9,
    depth: 0.9,
    clearanceBottom: 0,
    velocityZ: 0,
    hit: false,
  };

  const p = createInitialPlayerState();
  assert.equal(checkObstacleCollision(p, -15, log), true);

  p.y = 1.2;
  assert.equal(checkObstacleCollision(p, -15, log), false);
});

test('shield absorbs obstacle hit and hearts deplete to defeat', () => {
  const p = createInitialPlayerState();
  p.shieldActive = true;
  assert.equal(applyObstacleHit(p), 'shield-broken');
  assert.equal(p.hearts, 3);
  assert.equal(p.shieldActive, false);

  p.invulnTimer = 0;
  assert.equal(applyObstacleHit(p), 'damaged');
  assert.equal(p.hearts, 2);

  p.invulnTimer = 0;
  assert.equal(applyObstacleHit(p), 'damaged');
  p.invulnTimer = 0;
  assert.equal(applyObstacleHit(p), 'defeated');
  assert.equal(p.hearts, 0);
});

test('abilities, pickups, biomes, and difficulty curve behave as expected', () => {
  const p = createInitialPlayerState();
  p.abilityCharge = 100;
  assert.equal(activateCharacterAbility(p, 'amara'), true);
  assert.equal(p.shieldActive, true);
  assert.equal(p.abilityCharge, 0);

  const coinScore = calculatePickupScore('gold-coin', 20, true);
  assert.ok(coinScore.points > 30);
  assert.equal(coinScore.coins, 1);

  assert.equal(getBiomeForDistance(100), 'emerald-canopy');
  assert.equal(getBiomeForDistance(450), 'sunken-temple');
  assert.equal(getBiomeForDistance(900), 'underground-city');
  assert.equal(getBiomeForDistance(1400), 'lost-world');

  assert.ok(computeRunSpeed(1000) > computeRunSpeed(50));
});

test('missions, character/costume unlocks, and fair rewarded ads persist properly', () => {
  let save = createDefaultSaveData('2026-11-14');
  save = updateMissionProgress(save, { distance: 450 });
  const claimed = claimMissionReward(save, 'daily-run-400');
  assert.equal(claimed.reward, 80);
  assert.equal(claimed.save.totalCoins, 200);

  // Give enough coins to unlock Amara (220)
  const richSave = { ...claimed.save, totalCoins: 300 };
  const unlockChar = unlockOrSelectCharacter(richSave, 'amara');
  assert.equal(unlockChar.ok, true);
  assert.equal(unlockChar.save.selectedCharacter, 'amara');
  assert.equal(unlockChar.save.totalCoins, 80);

  const unlockCostume = unlockOrSelectCostume(
    { ...unlockChar.save, totalCoins: 200 },
    'amara',
    'amara-lotus'
  );
  assert.equal(unlockCostume.ok, true);
  assert.equal(unlockCostume.save.selectedCostumes.amara, 'amara-lotus');

  assert.equal(canWatchRewardedAd(unlockCostume.save, '2026-11-14'), true);
  const afterAd = grantRewardedAdBonus(unlockCostume.save, '2026-11-14');
  assert.equal(afterAd.totalCoins, unlockCostume.save.totalCoins + 100);

  const sanitized = sanitizeSaveData({ totalCoins: -50, bestScore: 900 }, '2026-11-14');
  assert.equal(sanitized.totalCoins, 120);
  assert.equal(sanitized.bestScore, 900);
  assert.equal(sanitized.activeMysteryId, 'mystery-ch1-sundial');
});

import {
  advanceCipherStep,
  applyMysteryCompletion,
  isMysteryUnlocked,
  submitCodexDecipher,
} from './mysteries';

test('ancient mystery cipher sequence advancing, resetting, and chapter completion', () => {
  const seq = ['serpent', 'jaguar', 'sun'] as const;
  const s1 = advanceCipherStep([...seq], 0, 'serpent');
  assert.equal(s1.matched, true);
  assert.equal(s1.nextIndex, 1);

  // Wrong rune resets progress cleanly
  const wrong = advanceCipherStep([...seq], 1, 'lotus');
  assert.equal(wrong.matched, false);
  assert.equal(wrong.reset, true);
  assert.equal(wrong.nextIndex, 0);

  // Complete full sequence
  const s2 = advanceCipherStep([...seq], 1, 'jaguar');
  const s3 = advanceCipherStep([...seq], s2.nextIndex, 'sun');
  assert.equal(s3.completed, true);
  assert.equal(s3.nextIndex, 0);
});

test('solving mystery chapters unlocks next chapter, lore fragment, and biomes', () => {
  let save = createDefaultSaveData('2026-11-14');
  assert.equal(isMysteryUnlocked(save, 'mystery-ch1-sundial'), true);
  assert.equal(isMysteryUnlocked(save, 'mystery-ch2-obelisk'), false);

  const ch1Done = applyMysteryCompletion(save, 'mystery-ch1-sundial');
  save = ch1Done.save;
  assert.equal(ch1Done.firstTimeSolve, true);
  assert.equal(isMysteryUnlocked(save, 'mystery-ch2-obelisk'), true);
  assert.equal(save.activeMysteryId, 'mystery-ch2-obelisk');
  assert.ok(save.discoveredLoreIds.includes('mystery-ch1-sundial'));

  // Solving Ch2 unlocks Sunken Temple biome
  const ch2Done = applyMysteryCompletion(save, 'mystery-ch2-obelisk');
  assert.equal(ch2Done.unlockedBiome, 'sunken-temple');
  assert.ok(ch2Done.save.unlockedBiomes.includes('sunken-temple'));

  // Codex decipher mini-puzzle awards bonus only on exact sequence match
  const badAttempt = submitCodexDecipher(ch2Done.save, 'mystery-ch1-sundial', ['lotus', 'sun']);
  assert.equal(badAttempt.ok, false);

  const goodAttempt = submitCodexDecipher(ch2Done.save, 'mystery-ch1-sundial', ['sun', 'lotus']);
  assert.equal(goodAttempt.ok, true);
  assert.ok(goodAttempt.bonusCoins > 0);
  assert.ok(goodAttempt.save.decipheredLoreIds.includes('mystery-ch1-sundial'));
});
