import { createDefaultSaveData } from './catalog';
import { canWatchRewardedAd, grantRewardedAdBonus, sanitizeSaveData } from './rules';
import type { SaveData } from './types';

const SAVE_STORAGE_KEY = 'jungle_rush_lost_world_save_v1';

export function getTodayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

export function loadSaveData(): SaveData {
  const today = getTodayKey();
  try {
    const raw = localStorage.getItem(SAVE_STORAGE_KEY);
    if (!raw) return createDefaultSaveData(today);
    return sanitizeSaveData(JSON.parse(raw), today);
  } catch {
    return createDefaultSaveData(today);
  }
}

export function persistSaveData(save: SaveData): void {
  try {
    localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(save));
  } catch {
    // Ignore quota failures gracefully
  }
}

export interface AdMobBridgeStatus {
  mode: 'capacitor-admob' | 'web-preview';
  testAdUnitId: string;
}

export const ADMOB_CONFIG: AdMobBridgeStatus = {
  mode:
    typeof window !== 'undefined' &&
    Boolean((window as unknown as { Capacitor?: { Plugins?: { AdMob?: unknown } } }).Capacitor?.Plugins?.AdMob)
      ? 'capacitor-admob'
      : 'web-preview',
  // Official Google AdMob Android Rewarded Test Ad Unit ID (replace with production ID before Play Store release)
  testAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
};

/**
 * Fair, player-initiated Rewarded Ad service.
 * Never interrupts active gameplay; bridges directly to Capacitor AdMob on Android
 * or runs a short transparent preview countdown on web.
 */
export async function showOptionalRewardedAd(
  save: SaveData,
  onProgress?: (secondsRemaining: number) => void
): Promise<{ granted: boolean; updatedSave: SaveData }> {
  const today = getTodayKey();
  if (!canWatchRewardedAd(save, today)) {
    return { granted: false, updatedSave: save };
  }

  // Native Android Capacitor AdMob hook if installed
  const capAdMob = (
    window as unknown as {
      Capacitor?: {
        Plugins?: {
          AdMob?: {
            prepareRewardVideoAd?: (opts: { adId: string; isTesting: boolean }) => Promise<void>;
            showRewardVideoAd?: () => Promise<{ type: string; amount: number }>;
          };
        };
      };
    }
  ).Capacitor?.Plugins?.AdMob;

  if (capAdMob?.prepareRewardVideoAd && capAdMob?.showRewardVideoAd) {
    try {
      await capAdMob.prepareRewardVideoAd({
        adId: ADMOB_CONFIG.testAdUnitId,
        isTesting: true,
      });
      await capAdMob.showRewardVideoAd();
      const updatedSave = grantRewardedAdBonus(save, today);
      persistSaveData(updatedSave);
      return { granted: true, updatedSave };
    } catch {
      return { granted: false, updatedSave: save };
    }
  }

  // Transparent 3-second web preview simulation
  for (let sec = 3; sec >= 1; sec -= 1) {
    onProgress?.(sec);
    await new Promise((r) => setTimeout(r, 1000));
  }
  onProgress?.(0);

  const updatedSave = grantRewardedAdBonus(save, today);
  persistSaveData(updatedSave);
  return { granted: true, updatedSave };
}
