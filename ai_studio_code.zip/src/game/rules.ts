import { BIOMES, BIOME_ORDER, CHARACTERS, MISSIONS, createDefaultSaveData } from './catalog';
import type {
  BiomeId,
  CharacterId,
  ObstacleBox,
  PlayerPhysicsState,
  SaveData,
} from './types';

export const LANE_WIDTH = 2.65;
export const GRAVITY = -34;
export const JUMP_VELOCITY = 13.6;
export const JUMP_CUT_FACTOR = 0.48;
export const COYOTE_TIME = 0.11;
export const JUMP_BUFFER_TIME = 0.13;
export const SLIDE_DURATION = 0.68;
export const PLAYER_STAND_HEIGHT = 1.8;
export const PLAYER_SLIDE_HEIGHT = 0.78;
export const PLAYER_HALF_WIDTH = 0.45;
export const BASE_RUN_SPEED = 15.5;
export const MAX_RUN_SPEED = 31.5;
export const DAILY_REWARDED_AD_CAP = 5;
export const REWARDED_AD_COIN_BONUS = 100;

export function clampLane(lane: number): number {
  return Math.max(-1, Math.min(1, Math.round(lane)));
}

export function getLaneCenterX(lane: number): number {
  return clampLane(lane) * LANE_WIDTH;
}

export function createInitialPlayerState(): PlayerPhysicsState {
  return {
    lane: 0,
    x: 0,
    y: 0,
    vy: 0,
    grounded: true,
    coyoteTimer: COYOTE_TIME,
    jumpBufferTimer: 0,
    slideTimer: 0,
    abilityCharge: 35,
    abilityActiveTimer: 0,
    invulnTimer: 0,
    hearts: 3,
    maxHearts: 3,
    shieldActive: false,
    magnetTimer: 0,
    multiplierTimer: 0,
    secretRoomTimer: 0,
  };
}

export function computeRunSpeed(distanceMeters: number, speedBonus = 0, inSecretRoom = false): number {
  const ramp = Math.min(1, distanceMeters / 1600);
  const base = BASE_RUN_SPEED + (MAX_RUN_SPEED - BASE_RUN_SPEED) * Math.pow(ramp, 0.85);
  const roomBoost = inSecretRoom ? 2.5 : 0;
  return base * (1 + speedBonus) + roomBoost;
}

export function getBiomeForDistance(distanceMeters: number, startBiome: BiomeId = 'emerald-canopy'): BiomeId {
  const startOffset = BIOMES[startBiome].unlockDistance;
  const effective = distanceMeters + startOffset;
  let active: BiomeId = 'emerald-canopy';
  for (const id of BIOME_ORDER) {
    if (effective >= BIOMES[id].unlockDistance) {
      active = id;
    }
  }
  return active;
}

export function triggerJump(player: PlayerPhysicsState): boolean {
  if (player.grounded || player.coyoteTimer > 0) {
    player.vy = JUMP_VELOCITY;
    player.grounded = false;
    player.coyoteTimer = 0;
    player.jumpBufferTimer = 0;
    player.slideTimer = 0;
    return true;
  }
  player.jumpBufferTimer = JUMP_BUFFER_TIME;
  return false;
}

export function releaseJumpEarly(player: PlayerPhysicsState): void {
  if (player.vy > 0) {
    player.vy *= JUMP_CUT_FACTOR;
  }
}

export function triggerSlide(player: PlayerPhysicsState): boolean {
  if (player.slideTimer > 0.15) return false;
  player.slideTimer = SLIDE_DURATION;
  if (!player.grounded && player.vy > -12) {
    player.vy = -18; // Fast slam down into slide
  }
  return true;
}

export function stepPlayerPhysics(
  player: PlayerPhysicsState,
  dt: number,
  groundY = 0
): { landed: boolean; jumpedFromBuffer: boolean } {
  let landed = false;
  let jumpedFromBuffer = false;

  const targetX = getLaneCenterX(player.lane);
  const alpha = 1 - Math.exp(-16 * dt);
  player.x += (targetX - player.x) * alpha;

  if (player.grounded) {
    player.coyoteTimer = COYOTE_TIME;
  } else {
    player.coyoteTimer = Math.max(0, player.coyoteTimer - dt);
  }

  if (player.jumpBufferTimer > 0) {
    player.jumpBufferTimer = Math.max(0, player.jumpBufferTimer - dt);
  }

  if (player.slideTimer > 0) {
    player.slideTimer = Math.max(0, player.slideTimer - dt);
  }
  if (player.invulnTimer > 0) {
    player.invulnTimer = Math.max(0, player.invulnTimer - dt);
  }
  if (player.abilityActiveTimer > 0) {
    player.abilityActiveTimer = Math.max(0, player.abilityActiveTimer - dt);
  }
  if (player.magnetTimer > 0) {
    player.magnetTimer = Math.max(0, player.magnetTimer - dt);
  }
  if (player.multiplierTimer > 0) {
    player.multiplierTimer = Math.max(0, player.multiplierTimer - dt);
  }
  if (player.secretRoomTimer > 0) {
    player.secretRoomTimer = Math.max(0, player.secretRoomTimer - dt);
  }

  // Vertical integration
  if (!player.grounded) {
    player.vy += GRAVITY * dt;
    player.y += player.vy * dt;
    if (player.y <= groundY) {
      player.y = groundY;
      player.vy = 0;
      player.grounded = true;
      landed = true;
      if (player.jumpBufferTimer > 0) {
        jumpedFromBuffer = triggerJump(player);
      }
    }
  } else if (player.y > groundY + 0.01) {
    player.grounded = false;
  }

  return { landed, jumpedFromBuffer };
}

export function getPlayerHeight(player: PlayerPhysicsState): number {
  return player.slideTimer > 0 && player.grounded ? PLAYER_SLIDE_HEIGHT : PLAYER_STAND_HEIGHT;
}

export function checkObstacleCollision(
  player: PlayerPhysicsState,
  playerZ: number,
  obs: ObstacleBox
): boolean {
  if (obs.hit) return false;

  const dz = Math.abs(playerZ - obs.z);
  const zHalf = obs.depth * 0.5 + 0.36;
  if (dz > zHalf) return false;

  const obsCenterX = getLaneCenterX(obs.lane);
  const dx = Math.abs(player.x - obsCenterX);
  const xHalf = obs.width * 0.5 + PLAYER_HALF_WIDTH;
  if (dx > xHalf) return false;

  const playerBottom = player.y;
  const playerTop = player.y + getPlayerHeight(player);

  if (obs.kind === 'temple-pit') {
    // Collides if player drops below floor level over the pit
    return playerBottom < 0.35;
  }

  const obsBottom = obs.clearanceBottom;
  const obsTop = obs.clearanceBottom + obs.height;
  return playerBottom < obsTop - 0.1 && playerTop > obsBottom + 0.08;
}

export function applyObstacleHit(
  player: PlayerPhysicsState
): 'ignored' | 'shield-broken' | 'damaged' | 'defeated' {
  if (player.invulnTimer > 0 || player.abilityActiveTimer > 0) {
    return 'ignored';
  }
  if (player.shieldActive) {
    player.shieldActive = false;
    player.invulnTimer = 1.4;
    return 'shield-broken';
  }
  player.hearts = Math.max(0, player.hearts - 1);
  player.invulnTimer = 1.6;
  if (player.hearts <= 0) {
    return 'defeated';
  }
  return 'damaged';
}

export function activateCharacterAbility(
  player: PlayerPhysicsState,
  characterId: CharacterId
): boolean {
  if (player.abilityCharge < 100) return false;
  player.abilityCharge = 0;

  if (characterId === 'kaelen') {
    player.abilityActiveTimer = 3.2;
    player.magnetTimer = Math.max(player.magnetTimer, 3.5);
  } else if (characterId === 'amara') {
    player.shieldActive = true;
    player.hearts = Math.min(player.maxHearts, player.hearts + 1);
    player.abilityActiveTimer = 2.0;
  } else if (characterId === 'torin') {
    player.abilityActiveTimer = 4.0;
    player.invulnTimer = Math.max(player.invulnTimer, 4.0);
  } else {
    player.multiplierTimer = Math.max(player.multiplierTimer, 6.0);
    player.magnetTimer = Math.max(player.magnetTimer, 6.0);
    player.abilityActiveTimer = 2.5;
  }
  return true;
}

export function calculatePickupScore(
  kind: 'gold-coin' | 'emerald-relic',
  combo: number,
  multiplierActive: boolean
): { points: number; coins: number; relics: number; chargeGain: number } {
  const mult = (multiplierActive ? 2 : 1) * (1 + Math.min(4, Math.floor(combo / 10)) * 0.25);
  if (kind === 'emerald-relic') {
    return {
      points: Math.round(120 * mult),
      coins: 5,
      relics: 1,
      chargeGain: 18,
    };
  }
  return {
    points: Math.round(15 * mult),
    coins: 1,
    relics: 0,
    chargeGain: 5,
  };
}

export function updateMissionProgress(
  save: SaveData,
  increments: Partial<Record<'distance' | 'coins' | 'relics' | 'slides' | 'jumps' | 'secretRooms' | 'bosses', number>>
): SaveData {
  const nextProgress = { ...save.missionProgress };
  for (const mission of MISSIONS) {
    const delta = increments[mission.metric] ?? 0;
    if (delta > 0) {
      const prev = nextProgress[mission.id] ?? 0;
      nextProgress[mission.id] = Math.min(mission.target, prev + delta);
    }
  }
  return {
    ...save,
    missionProgress: nextProgress,
  };
}

export function claimMissionReward(save: SaveData, missionId: string): { save: SaveData; reward: number } {
  const mission = MISSIONS.find((m) => m.id === missionId);
  if (!mission) return { save, reward: 0 };
  if (save.claimedMissions.includes(missionId)) return { save, reward: 0 };
  const progress = save.missionProgress[missionId] ?? 0;
  if (progress < mission.target) return { save, reward: 0 };

  return {
    reward: mission.rewardCoins,
    save: {
      ...save,
      totalCoins: save.totalCoins + mission.rewardCoins,
      claimedMissions: [...save.claimedMissions, missionId],
    },
  };
}

export function unlockOrSelectCharacter(
  save: SaveData,
  charId: CharacterId
): { save: SaveData; ok: boolean; reason?: string } {
  if (save.unlockedCharacters.includes(charId)) {
    return {
      ok: true,
      save: { ...save, selectedCharacter: charId },
    };
  }
  const def = CHARACTERS[charId];
  if (save.totalCoins < def.unlockCost) {
    return { ok: false, save, reason: 'Not enough coins' };
  }
  return {
    ok: true,
    save: {
      ...save,
      totalCoins: save.totalCoins - def.unlockCost,
      unlockedCharacters: [...save.unlockedCharacters, charId],
      selectedCharacter: charId,
    },
  };
}

export function unlockOrSelectCostume(
  save: SaveData,
  charId: CharacterId,
  costumeId: string
): { save: SaveData; ok: boolean } {
  const charDef = CHARACTERS[charId];
  const costume = charDef.costumes.find((c) => c.id === costumeId);
  if (!costume) return { save, ok: false };

  if (save.unlockedCostumes.includes(costumeId)) {
    return {
      ok: true,
      save: {
        ...save,
        selectedCostumes: { ...save.selectedCostumes, [charId]: costumeId },
      },
    };
  }

  if (save.totalCoins < costume.price) {
    return { save, ok: false };
  }

  return {
    ok: true,
    save: {
      ...save,
      totalCoins: save.totalCoins - costume.price,
      unlockedCostumes: [...save.unlockedCostumes, costumeId],
      selectedCostumes: { ...save.selectedCostumes, [charId]: costumeId },
    },
  };
}

export function canWatchRewardedAd(save: SaveData, todayKey: string): boolean {
  const used = save.lastAdDay === todayKey ? save.rewardedAdsToday : 0;
  return used < DAILY_REWARDED_AD_CAP;
}

export function grantRewardedAdBonus(save: SaveData, todayKey: string): SaveData {
  const prevCount = save.lastAdDay === todayKey ? save.rewardedAdsToday : 0;
  return {
    ...save,
    totalCoins: save.totalCoins + REWARDED_AD_COIN_BONUS,
    rewardedAdsToday: prevCount + 1,
    lastAdDay: todayKey,
  };
}

export function sanitizeSaveData(raw: unknown, todayKey = '2026-11-14'): SaveData {
  const defaults = createDefaultSaveData(todayKey);
  if (!raw || typeof raw !== 'object') return defaults;
  const obj = raw as Partial<SaveData>;

  return {
    ...defaults,
    ...obj,
    totalCoins: typeof obj.totalCoins === 'number' && obj.totalCoins >= 0 ? Math.floor(obj.totalCoins) : defaults.totalCoins,
    totalRelics: typeof obj.totalRelics === 'number' && obj.totalRelics >= 0 ? Math.floor(obj.totalRelics) : defaults.totalRelics,
    bestScore: typeof obj.bestScore === 'number' && obj.bestScore >= 0 ? Math.floor(obj.bestScore) : defaults.bestScore,
    bestDistance: typeof obj.bestDistance === 'number' && obj.bestDistance >= 0 ? Math.floor(obj.bestDistance) : defaults.bestDistance,
    unlockedCharacters: Array.isArray(obj.unlockedCharacters) && obj.unlockedCharacters.length > 0
      ? obj.unlockedCharacters
      : defaults.unlockedCharacters,
    unlockedCostumes: Array.isArray(obj.unlockedCostumes) && obj.unlockedCostumes.length > 0
      ? obj.unlockedCostumes
      : defaults.unlockedCostumes,
    unlockedBiomes: Array.isArray(obj.unlockedBiomes) && obj.unlockedBiomes.length > 0
      ? obj.unlockedBiomes
      : defaults.unlockedBiomes,
    selectedCostumes: { ...defaults.selectedCostumes, ...(obj.selectedCostumes ?? {}) },
    missionProgress: { ...defaults.missionProgress, ...(obj.missionProgress ?? {}) },
    claimedMissions: Array.isArray(obj.claimedMissions) ? obj.claimedMissions : defaults.claimedMissions,
    activeMysteryId: typeof obj.activeMysteryId === 'string' && obj.activeMysteryId.length > 0 ? obj.activeMysteryId : defaults.activeMysteryId,
    solvedMysteries: Array.isArray(obj.solvedMysteries) ? obj.solvedMysteries : defaults.solvedMysteries,
    discoveredLoreIds: Array.isArray(obj.discoveredLoreIds) ? obj.discoveredLoreIds : defaults.discoveredLoreIds,
    decipheredLoreIds: Array.isArray(obj.decipheredLoreIds) ? obj.decipheredLoreIds : defaults.decipheredLoreIds,
    settings: { ...defaults.settings, ...(obj.settings ?? {}) },
  };
}
