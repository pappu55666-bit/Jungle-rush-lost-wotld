export type GameScreenState = 'title' | 'playing' | 'paused' | 'gameover';

export type BiomeId =
  | 'emerald-canopy'
  | 'sunken-temple'
  | 'underground-city'
  | 'lost-world';

export type CharacterId = 'kaelen' | 'amara' | 'torin' | 'lyra';

export type GraphicsPreset = 'budget' | 'balanced' | 'high';

export type ObstacleKind =
  | 'fallen-log'      // Jump over
  | 'stone-arch'      // Slide under
  | 'spike-totem'     // Switch lane
  | 'rolling-boulder' // Moves toward player in lane; switch lane
  | 'temple-pit';     // Jump over gap

export type PickupKind =
  | 'gold-coin'
  | 'emerald-relic'
  | 'magnet-orb'
  | 'shield-orb'
  | 'multiplier-orb';

export interface BiomeDef {
  id: BiomeId;
  name: string;
  subtitle: string;
  unlockDistance: number;
  skyColor: number;
  fogColor: number;
  fogDensity: number;
  groundColor: number;
  stoneColor: number;
  accentColor: number;
  waterColor: number;
  ambientSky: number;
  ambientGround: number;
  sunColor: number;
  sunIntensity: number;
}

export interface CostumeDef {
  id: string;
  name: string;
  price: number;
  primaryColor: number;
  accentColor: number;
  trimColor: number;
}

export interface CharacterDef {
  id: CharacterId;
  name: string;
  title: string;
  abilityName: string;
  abilityDesc: string;
  unlockCost: number;
  speedBonus: number;
  magnetRangeBonus: number;
  costumes: CostumeDef[];
}

export interface MissionDef {
  id: string;
  title: string;
  category: 'daily' | 'mystery' | 'treasure';
  metric: 'distance' | 'coins' | 'relics' | 'slides' | 'jumps' | 'secretRooms' | 'bosses';
  target: number;
  rewardCoins: number;
}

export interface SettingsData {
  soundEnabled: boolean;
  musicEnabled: boolean;
  soundVolume: number;
  graphicsPreset: GraphicsPreset;
  showTouchControls: boolean;
}

export type RuneSymbolId = 'sun' | 'jaguar' | 'serpent' | 'lotus';

export interface MysteryChapterDef {
  id: string;
  chapterNumber: number;
  title: string;
  difficultyLabel: 'Initiate' | 'Adept' | 'Scholar' | 'Master';
  riddleClue: string;
  sequence: RuneSymbolId[];
  loreTitle: string;
  loreText: string;
  rewardCoins: number;
  rewardRelics: number;
  unlocksBiome?: BiomeId;
}

export interface SaveData {
  totalCoins: number;
  totalRelics: number;
  bestScore: number;
  bestDistance: number;
  selectedCharacter: CharacterId;
  unlockedCharacters: CharacterId[];
  selectedCostumes: Record<CharacterId, string>;
  unlockedCostumes: string[];
  unlockedBiomes: BiomeId[];
  selectedStartBiome: BiomeId;
  missionProgress: Record<string, number>;
  claimedMissions: string[];
  activeMysteryId: string;
  solvedMysteries: string[];
  discoveredLoreIds: string[];
  decipheredLoreIds: string[];
  rewardedAdsToday: number;
  lastAdDay: string;
  settings: SettingsData;
}

export interface PlayerPhysicsState {
  lane: number; // -1, 0, 1
  x: number;
  y: number;
  vy: number;
  grounded: boolean;
  coyoteTimer: number;
  jumpBufferTimer: number;
  slideTimer: number;
  abilityCharge: number; // 0 to 100
  abilityActiveTimer: number;
  invulnTimer: number;
  hearts: number;
  maxHearts: number;
  shieldActive: boolean;
  magnetTimer: number;
  multiplierTimer: number;
  secretRoomTimer: number;
}

export interface ObstacleBox {
  id: number;
  kind: ObstacleKind;
  lane: number; // -1, 0, 1
  z: number;
  width: number;
  height: number;
  depth: number;
  clearanceBottom: number; // > 0 means can slide under
  velocityZ: number;
  hit: boolean;
}

export interface RunHudSnapshot {
  score: number;
  distance: number;
  runCoins: number;
  runRelics: number;
  combo: number;
  hearts: number;
  maxHearts: number;
  shieldActive: boolean;
  magnetRemaining: number;
  multiplierRemaining: number;
  abilityCharge: number;
  abilityActive: boolean;
  biomeId: BiomeId;
  biomeName: string;
  inSecretRoom: boolean;
  bossActive: boolean;
  bossHp: number;
  bossMaxHp: number;
  bossTelegraphLane: number | null;
  activeMissionTitle: string;
  activeMissionCurrent: number;
  activeMissionTarget: number;
  speed: number;
  mysteryId: string;
  mysteryTitle: string;
  mysterySequence: RuneSymbolId[];
  mysteryStepIndex: number;
  mysteryBannerText: string | null;
}

export interface RunOutcomeSnapshot {
  victory: boolean;
  score: number;
  bestScore: number;
  distance: number;
  coinsCollected: number;
  relicsCollected: number;
  bossesCleared: number;
  secretRoomsFound: number;
  newBiomeUnlocked: BiomeId | null;
  revivedUsed: boolean;
}
