import * as THREE from 'three';
import { RUNE_META } from './mysteries';
import type { ProceduralTextureSet } from './textures';
import type { ObstacleKind, PickupKind, RuneSymbolId } from './types';

export interface ExplorerRig {
  root: THREE.Group;
  bodyPivot: THREE.Group;
  torso: THREE.Mesh;
  scarf: THREE.Mesh;
  backpack: THREE.Mesh;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  shieldSphere: THREE.Mesh;
  auraRing: THREE.Mesh;
  primaryMat: THREE.MeshStandardMaterial;
  accentMat: THREE.MeshStandardMaterial;
  trimMat: THREE.MeshStandardMaterial;
}

export function buildExplorerRig(shadowDisc: THREE.CanvasTexture): ExplorerRig {
  const root = new THREE.Group();

  // Contact shadow disc grounded at y = 0.02
  const shadowGeo = new THREE.CircleGeometry(0.68, 24);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowDisc,
    transparent: true,
    depthWrite: false,
    opacity: 0.72,
  });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.position.y = 0.02;
  root.add(shadow);

  const primaryMat = new THREE.MeshStandardMaterial({
    color: 0xb8864b,
    roughness: 0.72,
    metalness: 0.08,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: 0x2d7a4f,
    roughness: 0.55,
    metalness: 0.12,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0xe6b446,
    roughness: 0.24,
    metalness: 0.85,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xdba982,
    roughness: 0.68,
    metalness: 0.02,
  });
  const bootMat = new THREE.MeshStandardMaterial({
    color: 0x3b2718,
    roughness: 0.82,
    metalness: 0.05,
  });

  const bodyPivot = new THREE.Group();
  root.add(bodyPivot);

  // Torso (Primary silhouette)
  const torsoGeo = new THREE.BoxGeometry(0.58, 0.72, 0.34);
  const torso = new THREE.Mesh(torsoGeo, primaryMat);
  torso.position.y = 1.04;
  torso.castShadow = true;
  bodyPivot.add(torso);

  // Explorer Scarf / Mantle (Secondary read)
  const scarfGeo = new THREE.TorusGeometry(0.28, 0.08, 8, 18);
  scarfGeo.rotateX(Math.PI / 2);
  const scarf = new THREE.Mesh(scarfGeo, accentMat);
  scarf.position.y = 1.38;
  scarf.castShadow = true;
  bodyPivot.add(scarf);

  // Golden Belt Buckle (Accent detail)
  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.61, 0.1, 0.37), bootMat);
  belt.position.y = 0.76;
  bodyPivot.add(belt);
  const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.06), trimMat);
  buckle.position.set(0, 0.76, -0.19);
  bodyPivot.add(buckle);

  // Relic Backpack + Lantern Core
  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.48, 0.24), bootMat);
  backpack.position.set(0, 1.06, 0.26);
  backpack.castShadow = true;
  bodyPivot.add(backpack);

  const packCompass = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.08, 12), trimMat);
  packCompass.rotation.x = Math.PI / 2;
  packCompass.position.set(0, 1.12, 0.39);
  bodyPivot.add(packCompass);

  // Head + Explorer Brim Hat / Goggles
  const head = new THREE.Group();
  head.position.y = 1.58;
  bodyPivot.add(head);

  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.22, 16, 14), skinMat);
  cranium.castShadow = true;
  head.add(cranium);

  const hatBrim = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.4, 0.05, 16), accentMat);
  hatBrim.position.y = 0.14;
  hatBrim.castShadow = true;
  head.add(hatBrim);

  const hatCrown = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.23, 0.22, 14), primaryMat);
  hatCrown.position.y = 0.24;
  hatCrown.castShadow = true;
  head.add(hatCrown);

  const hatBand = new THREE.Mesh(new THREE.CylinderGeometry(0.235, 0.235, 0.05, 14), trimMat);
  hatBand.position.y = 0.17;
  head.add(hatBand);

  // Articulated Arms
  const makeArm = (xOffset: number) => {
    const armPivot = new THREE.Group();
    armPivot.position.set(xOffset, 1.32, 0);
    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.34, 4, 8), primaryMat);
    upper.position.y = -0.22;
    upper.castShadow = true;
    armPivot.add(upper);
    const glove = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), bootMat);
    glove.position.y = -0.45;
    armPivot.add(glove);
    bodyPivot.add(armPivot);
    return armPivot;
  };
  const leftArm = makeArm(-0.39);
  const rightArm = makeArm(0.39);

  // Articulated Legs
  const makeLeg = (xOffset: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(xOffset, 0.7, 0);
    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.36, 4, 8), accentMat);
    thigh.position.y = -0.24;
    thigh.castShadow = true;
    legPivot.add(thigh);
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.3), bootMat);
    boot.position.set(0, -0.58, -0.04);
    boot.castShadow = true;
    legPivot.add(boot);
    bodyPivot.add(legPivot);
    return legPivot;
  };
  const leftLeg = makeLeg(-0.16);
  const rightLeg = makeLeg(0.16);

  // Jade Shield Bubble (visible when shield active)
  const shieldSphere = new THREE.Mesh(
    new THREE.SphereGeometry(1.12, 20, 16),
    new THREE.MeshStandardMaterial({
      color: 0x3ef0b4,
      emissive: 0x168060,
      emissiveIntensity: 0.7,
      transparent: true,
      opacity: 0.28,
      roughness: 0.15,
      metalness: 0.2,
      depthWrite: false,
    })
  );
  shieldSphere.position.y = 1.0;
  shieldSphere.visible = false;
  root.add(shieldSphere);

  // Ability Ground Ring
  const auraRing = new THREE.Mesh(
    new THREE.RingGeometry(0.85, 1.15, 28),
    new THREE.MeshBasicMaterial({
      color: 0xffcf48,
      transparent: true,
      opacity: 0.75,
      side: THREE.DoubleSide,
      depthWrite: false,
    })
  );
  auraRing.rotation.x = -Math.PI / 2;
  auraRing.position.y = 0.05;
  auraRing.visible = false;
  root.add(auraRing);

  return {
    root,
    bodyPivot,
    torso,
    scarf,
    backpack,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    shieldSphere,
    auraRing,
    primaryMat,
    accentMat,
    trimMat,
  };
}

export function buildObstacleMesh(kind: ObstacleKind, textures: ProceduralTextureSet): THREE.Group {
  const group = new THREE.Group();

  if (kind === 'fallen-log') {
    const barkMat = new THREE.MeshStandardMaterial({
      map: textures.barkColor,
      color: 0xffffff,
      roughness: 0.88,
      metalness: 0.02,
    });
    const mossMat = new THREE.MeshStandardMaterial({
      color: 0x3b7a38,
      roughness: 0.8,
      metalness: 0.0,
    });
    const amberWarnMat = new THREE.MeshStandardMaterial({
      color: 0xffc745,
      emissive: 0x995a00,
      emissiveIntensity: 0.45,
      roughness: 0.35,
      metalness: 0.3,
    });

    const log = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.46, 2.3, 12), barkMat);
    log.rotation.z = Math.PI / 2;
    log.position.y = 0.44;
    log.castShadow = true;
    log.receiveShadow = true;
    group.add(log);

    const stub = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 0.55, 8), barkMat);
    stub.position.set(0.55, 0.78, 0.12);
    stub.rotation.z = -0.45;
    group.add(stub);

    const moss1 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.28, 0), mossMat);
    moss1.position.set(-0.5, 0.75, 0.1);
    moss1.scale.set(1.4, 0.5, 0.9);
    group.add(moss1);

    const moss2 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.24, 0), mossMat);
    moss2.position.set(0.25, 0.76, -0.15);
    moss2.scale.set(1.2, 0.45, 0.85);
    group.add(moss2);

    // Subtle glowing spore trim so jump clearance reads immediately at speed
    const trim = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.06, 0.1), amberWarnMat);
    trim.position.set(0, 0.86, 0.32);
    group.add(trim);
  } else if (kind === 'stone-arch') {
    const stoneMat = new THREE.MeshStandardMaterial({
      map: textures.stoneColor,
      bumpMap: textures.stoneBump,
      bumpScale: 0.05,
      color: 0xffffff,
      roughness: 0.78,
      metalness: 0.06,
    });
    const vineMat = new THREE.MeshStandardMaterial({
      color: 0x2f6b35,
      roughness: 0.7,
    });
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xe6b446,
      roughness: 0.25,
      metalness: 0.8,
    });

    const leftPillar = new THREE.Mesh(new THREE.BoxGeometry(0.45, 2.7, 0.72), stoneMat);
    leftPillar.position.set(-1.12, 1.35, 0);
    leftPillar.castShadow = true;
    group.add(leftPillar);

    const rightPillar = new THREE.Mesh(new THREE.BoxGeometry(0.45, 2.7, 0.72), stoneMat);
    rightPillar.position.set(1.12, 1.35, 0);
    rightPillar.castShadow = true;
    group.add(rightPillar);

    // Crossbar sits at y = 1.08..2.65 so player MUST slide underneath
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(2.72, 1.35, 0.82), stoneMat);
    lintel.position.set(0, 1.85, 0);
    lintel.castShadow = true;
    group.add(lintel);

    const relief = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.24, 0.88), goldMat);
    relief.position.set(0, 1.32, 0);
    group.add(relief);

    // Hanging jungle vines
    for (let i = -2; i <= 2; i++) {
      const vine = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.02, 0.45, 5), vineMat);
      vine.position.set(i * 0.38, 1.02, 0.35);
      group.add(vine);
    }
  } else if (kind === 'spike-totem') {
    const stoneMat = new THREE.MeshStandardMaterial({
      map: textures.stoneColor,
      bumpMap: textures.stoneBump,
      bumpScale: 0.05,
      color: 0xd9cbb0,
      roughness: 0.72,
      metalness: 0.1,
    });
    const maskMat = new THREE.MeshStandardMaterial({
      color: 0x993528,
      roughness: 0.5,
      metalness: 0.15,
    });
    const eyeMat = new THREE.MeshStandardMaterial({
      color: 0xff6238,
      emissive: 0xff3b1f,
      emissiveIntensity: 1.1,
      roughness: 0.2,
    });
    const spikeMat = new THREE.MeshStandardMaterial({
      color: 0x262933,
      roughness: 0.28,
      metalness: 0.82,
    });

    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.88, 0.38, 8), stoneMat);
    base.position.y = 0.19;
    base.castShadow = true;
    group.add(base);

    const column = new THREE.Mesh(new THREE.BoxGeometry(0.95, 1.9, 0.85), stoneMat);
    column.position.y = 1.3;
    column.castShadow = true;
    group.add(column);

    const mask = new THREE.Mesh(new THREE.BoxGeometry(1.06, 0.95, 0.92), maskMat);
    mask.position.y = 1.5;
    group.add(mask);

    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), eyeMat);
    eyeL.position.set(-0.22, 1.62, 0.44);
    group.add(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), eyeMat);
    eyeR.position.set(0.22, 1.62, 0.44);
    group.add(eyeR);

    for (let i = -1; i <= 1; i++) {
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.55, 6), spikeMat);
      spike.position.set(i * 0.3, 2.52, 0);
      group.add(spike);
    }
  } else if (kind === 'rolling-boulder') {
    const rockMat = new THREE.MeshStandardMaterial({
      map: textures.stoneColor,
      bumpMap: textures.stoneBump,
      bumpScale: 0.08,
      color: 0x9c8e78,
      roughness: 0.85,
      metalness: 0.05,
    });
    const runeMat = new THREE.MeshStandardMaterial({
      color: 0xff6d2e,
      emissive: 0xd93814,
      emissiveIntensity: 0.9,
      roughness: 0.3,
    });

    const sphere = new THREE.Mesh(new THREE.DodecahedronGeometry(0.92, 1), rockMat);
    sphere.position.y = 0.92;
    sphere.castShadow = true;
    sphere.name = 'boulderBody';
    group.add(sphere);

    const band = new THREE.Mesh(new THREE.TorusGeometry(0.88, 0.08, 6, 18), runeMat);
    band.position.y = 0.92;
    band.name = 'boulderBand';
    group.add(band);

    // Ground danger telegraph strip ahead of the boulder
    const strip = new THREE.Mesh(
      new THREE.PlaneGeometry(1.75, 7.5),
      new THREE.MeshBasicMaterial({
        color: 0xff5a26,
        transparent: true,
        opacity: 0.32,
        depthWrite: false,
      })
    );
    strip.rotation.x = -Math.PI / 2;
    strip.position.set(0, 0.03, 4.2);
    group.add(strip);
  } else if (kind === 'temple-pit') {
    const chasmMat = new THREE.MeshBasicMaterial({ color: 0x060b09 });
    const stoneMat = new THREE.MeshStandardMaterial({
      map: textures.stoneColor,
      color: 0x6b6456,
      roughness: 0.85,
    });
    const lanternMat = new THREE.MeshStandardMaterial({
      color: 0xffb838,
      emissive: 0xff8c1a,
      emissiveIntensity: 1.2,
    });

    const pit = new THREE.Mesh(new THREE.PlaneGeometry(2.25, 2.4), chasmMat);
    pit.rotation.x = -Math.PI / 2;
    pit.position.y = 0.025;
    group.add(pit);

    const edgeFront = new THREE.Mesh(new THREE.BoxGeometry(2.35, 0.14, 0.25), stoneMat);
    edgeFront.position.set(0, 0.07, 1.22);
    group.add(edgeFront);

    const edgeBack = new THREE.Mesh(new THREE.BoxGeometry(2.35, 0.14, 0.25), stoneMat);
    edgeBack.position.set(0, 0.07, -1.22);
    group.add(edgeBack);

    const postL = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.9, 6), stoneMat);
    postL.position.set(-1.12, 0.45, 1.2);
    group.add(postL);
    const orbL = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 8), lanternMat);
    orbL.position.set(-1.12, 0.96, 1.2);
    group.add(orbL);

    const postR = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.9, 6), stoneMat);
    postR.position.set(1.12, 0.45, 1.2);
    group.add(postR);
    const orbR = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 8), lanternMat);
    orbR.position.set(1.12, 0.96, 1.2);
    group.add(orbR);
  }

  return group;
}

export function buildPickupMesh(kind: PickupKind): THREE.Group {
  const group = new THREE.Group();

  if (kind === 'gold-coin') {
    const coinMat = new THREE.MeshStandardMaterial({
      color: 0xffcf40,
      emissive: 0x6b4200,
      emissiveIntensity: 0.35,
      roughness: 0.2,
      metalness: 0.9,
    });
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.09, 16), coinMat);
    rim.rotation.x = Math.PI / 2;
    group.add(rim);

    const inner = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.18, 0),
      new THREE.MeshStandardMaterial({
        color: 0xfff3a8,
        emissive: 0x996b00,
        emissiveIntensity: 0.45,
        roughness: 0.15,
        metalness: 0.95,
      })
    );
    inner.scale.set(1, 1, 0.45);
    group.add(inner);
  } else if (kind === 'emerald-relic') {
    const gemMat = new THREE.MeshStandardMaterial({
      color: 0x2df2a6,
      emissive: 0x0b7349,
      emissiveIntensity: 0.8,
      roughness: 0.12,
      metalness: 0.35,
    });
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xffd257,
      roughness: 0.2,
      metalness: 0.9,
    });
    const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.42, 0), gemMat);
    crystal.scale.set(0.85, 1.25, 0.85);
    group.add(crystal);

    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.52, 0.045, 8, 20), goldMat);
    group.add(ring);
  } else {
    const color =
      kind === 'magnet-orb' ? 0x3eb8ff : kind === 'shield-orb' ? 0x3ef0b4 : 0xff77e9;
    const core = new THREE.Mesh(
      new THREE.SphereGeometry(0.32, 14, 12),
      new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.85,
        roughness: 0.15,
        metalness: 0.3,
      })
    );
    group.add(core);
    const orbit = new THREE.Mesh(
      new THREE.TorusGeometry(0.48, 0.04, 8, 20),
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: color,
        emissiveIntensity: 0.5,
        roughness: 0.2,
        metalness: 0.8,
      })
    );
    orbit.rotation.x = Math.PI / 3;
    group.add(orbit);
  }

  return group;
}

export function buildSecretPortalMesh(textures: ProceduralTextureSet): THREE.Group {
  const group = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({
    map: textures.stoneColor,
    color: 0x62507d,
    roughness: 0.65,
    metalness: 0.2,
  });
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xffca48,
    roughness: 0.22,
    metalness: 0.88,
  });
  const vortexMat = new THREE.MeshBasicMaterial({
    color: 0x3ef2d6,
    transparent: true,
    opacity: 0.68,
    side: THREE.DoubleSide,
  });

  const leftCol = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.36, 3.2, 8), stoneMat);
  leftCol.position.set(-1.15, 1.6, 0);
  group.add(leftCol);

  const rightCol = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.36, 3.2, 8), stoneMat);
  rightCol.position.set(1.15, 1.6, 0);
  group.add(rightCol);

  const archRing = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.22, 8, 20, Math.PI), goldMat);
  archRing.position.set(0, 2.8, 0);
  group.add(archRing);

  const vortex = new THREE.Mesh(new THREE.CircleGeometry(1.02, 20), vortexMat);
  vortex.position.set(0, 1.75, 0);
  vortex.name = 'portalVortex';
  group.add(vortex);

  return group;
}

export function buildPalmTreeGroup(textures: ProceduralTextureSet): THREE.Group {
  const tree = new THREE.Group();
  const trunkMat = new THREE.MeshStandardMaterial({
    map: textures.barkColor,
    color: 0xc29e7a,
    roughness: 0.88,
  });
  const leafMat = new THREE.MeshStandardMaterial({
    color: 0x2d7a3c,
    roughness: 0.68,
    metalness: 0.02,
  });

  const seg1 = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.34, 2.6, 7), trunkMat);
  seg1.position.y = 1.3;
  seg1.rotation.z = 0.08;
  seg1.castShadow = true;
  tree.add(seg1);

  const seg2 = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.22, 2.5, 7), trunkMat);
  seg2.position.set(-0.18, 3.7, 0);
  seg2.rotation.z = 0.14;
  seg2.castShadow = true;
  tree.add(seg2);

  // Fronds radiating from crown
  const crown = new THREE.Group();
  crown.position.set(-0.32, 4.9, 0);
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const frond = new THREE.Mesh(new THREE.ConeGeometry(0.45, 2.2, 5), leafMat);
    frond.rotation.z = Math.PI / 2.4;
    frond.rotation.y = angle;
    frond.position.set(Math.cos(angle) * 0.9, -0.1, Math.sin(angle) * 0.9);
    frond.scale.set(0.55, 1, 1.4);
    crown.add(frond);
  }
  tree.add(crown);
  return tree;
}

export function buildTemplePillarGroup(textures: ProceduralTextureSet): THREE.Group {
  const pillar = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({
    map: textures.stoneColor,
    bumpMap: textures.stoneBump,
    bumpScale: 0.06,
    color: 0xffffff,
    roughness: 0.78,
  });
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xe6b446,
    roughness: 0.28,
    metalness: 0.82,
  });

  const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.7, 1.5), stoneMat);
  plinth.position.y = 0.35;
  pillar.add(plinth);

  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.6, 4.2, 8), stoneMat);
  shaft.position.y = 2.8;
  shaft.castShadow = true;
  pillar.add(shaft);

  const cap = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.55, 1.45), stoneMat);
  cap.position.y = 5.15;
  pillar.add(cap);

  const brazier = new THREE.Mesh(new THREE.SphereGeometry(0.32, 10, 10), goldMat);
  brazier.position.y = 5.65;
  pillar.add(brazier);

  return pillar;
}

export function buildSentinelBoss(textures: ProceduralTextureSet): THREE.Group {
  const boss = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({
    map: textures.stoneColor,
    bumpMap: textures.stoneBump,
    bumpScale: 0.08,
    color: 0x5c536e,
    roughness: 0.65,
    metalness: 0.25,
  });
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xffc745,
    roughness: 0.22,
    metalness: 0.9,
  });
  const coreMat = new THREE.MeshStandardMaterial({
    color: 0xff4c29,
    emissive: 0xff2e0a,
    emissiveIntensity: 1.5,
    roughness: 0.15,
  });

  const torso = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.8, 1.6), stoneMat);
  torso.position.y = 2.4;
  torso.castShadow = true;
  boss.add(torso);

  const crown = new THREE.Mesh(new THREE.ConeGeometry(1.1, 1.3, 6), goldMat);
  crown.position.y = 4.4;
  boss.add(crown);

  const eyeCore = new THREE.Mesh(new THREE.OctahedronGeometry(0.62, 0), coreMat);
  eyeCore.position.set(0, 2.5, 0.88);
  eyeCore.name = 'bossCore';
  boss.add(eyeCore);

  const leftFist = new THREE.Mesh(new THREE.DodecahedronGeometry(0.75, 0), stoneMat);
  leftFist.position.set(-2.2, 2.1, 0.4);
  leftFist.name = 'leftFist';
  boss.add(leftFist);

  const rightFist = new THREE.Mesh(new THREE.DodecahedronGeometry(0.75, 0), stoneMat);
  rightFist.position.set(2.2, 2.1, 0.4);
  rightFist.name = 'rightFist';
  boss.add(rightFist);

  const halo = new THREE.Mesh(new THREE.TorusGeometry(2.0, 0.1, 8, 28), goldMat);
  halo.position.set(0, 2.5, -0.5);
  halo.name = 'bossHalo';
  boss.add(halo);

  return boss;
}

export function buildFernRockGroup(): THREE.Group {
  const group = new THREE.Group();
  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x565c52,
    roughness: 0.9,
    metalness: 0.04,
  });
  const fernMat = new THREE.MeshStandardMaterial({
    color: 0x2f8743,
    roughness: 0.65,
    metalness: 0.02,
  });

  const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.9, 0), rockMat);
  rock.position.y = 0.45;
  rock.scale.set(1.2, 0.75, 1.0);
  group.add(rock);

  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + 0.4;
    const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.15, 5), fernMat);
    leaf.position.set(Math.cos(a) * 0.45, 0.85, Math.sin(a) * 0.45);
    leaf.rotation.z = -Math.cos(a) * 0.7;
    leaf.rotation.x = Math.sin(a) * 0.7;
    group.add(leaf);
  }
  return group;
}

export function buildTempleVistaBackdrop(textures: ProceduralTextureSet): THREE.Group {
  const vista = new THREE.Group();
  const cliffMat = new THREE.MeshStandardMaterial({
    map: textures.stoneColor,
    color: 0x4b5c49,
    roughness: 0.9,
  });
  const templeMat = new THREE.MeshStandardMaterial({
    map: textures.stoneColor,
    color: 0x9c8b68,
    roughness: 0.75,
  });
  const waterfallMat = new THREE.MeshStandardMaterial({
    color: 0x6ce2ee,
    emissive: 0x1b6e80,
    emissiveIntensity: 0.45,
    roughness: 0.15,
    metalness: 0.1,
  });
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xf0be4d,
    roughness: 0.25,
    metalness: 0.85,
  });

  // Grand Stepped Lost-World Ziggurat in the distance
  const tiers = [
    { w: 26, h: 6, d: 26, y: 3 },
    { w: 19, h: 5.5, d: 19, y: 8.75 },
    { w: 12, h: 5, d: 12, y: 14 },
  ];
  for (const t of tiers) {
    const tier = new THREE.Mesh(new THREE.BoxGeometry(t.w, t.h, t.d), templeMat);
    tier.position.set(0, t.y, 0);
    vista.add(tier);
  }
  const shrine = new THREE.Mesh(new THREE.BoxGeometry(6, 4.5, 6), goldMat);
  shrine.position.set(0, 18.75, 0);
  vista.add(shrine);

  // Flanking Waterfall Cliffs
  for (const side of [-1, 1]) {
    const cliff = new THREE.Mesh(new THREE.CylinderGeometry(8, 12, 26, 7), cliffMat);
    cliff.position.set(side * 34, 12, 6);
    vista.add(cliff);

    const fall = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 22), waterfallMat);
    fall.position.set(side * 27.5, 10, 11);
    fall.rotation.y = side * -0.35;
    vista.add(fall);
  }

  return vista;
}

export function buildRuneTabletMesh(
  runeId: RuneSymbolId,
  textures: ProceduralTextureSet
): THREE.Group {
  const meta = RUNE_META[runeId];
  const group = new THREE.Group();

  const stoneMat = new THREE.MeshStandardMaterial({
    map: textures.stoneColor,
    color: 0x5c645a,
    roughness: 0.72,
    metalness: 0.15,
  });
  const glyphMat = new THREE.MeshStandardMaterial({
    color: meta.colorHex,
    emissive: meta.colorHex,
    emissiveIntensity: 0.95,
    roughness: 0.18,
    metalness: 0.6,
  });

  // Carved stone plinth ring at ground
  const plinth = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.78, 0.2, 8), stoneMat);
  plinth.position.y = 0.1;
  group.add(plinth);

  // Outer carved stone ring framing the floating glyph
  const outerRing = new THREE.Mesh(new THREE.TorusGeometry(0.68, 0.09, 8, 18), stoneMat);
  outerRing.position.y = 1.25;
  outerRing.name = 'runeRing';
  group.add(outerRing);

  // Distinct silhouette per rune symbol
  const emblem = new THREE.Group();
  emblem.position.y = 1.25;
  emblem.name = 'runeEmblem';

  if (runeId === 'sun') {
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.26, 12, 10), glyphMat);
    emblem.add(core);
    const rays = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.055, 6, 8), glyphMat);
    emblem.add(rays);
  } else if (runeId === 'jaguar') {
    const diamond = new THREE.Mesh(new THREE.OctahedronGeometry(0.36, 0), glyphMat);
    diamond.scale.set(0.95, 1.25, 0.55);
    emblem.add(diamond);
    const fangL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 5), glyphMat);
    fangL.position.set(-0.26, 0.25, 0);
    fangL.rotation.z = 0.45;
    emblem.add(fangL);
    const fangR = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.28, 5), glyphMat);
    fangR.position.set(0.26, 0.25, 0);
    fangR.rotation.z = -0.45;
    emblem.add(fangR);
  } else if (runeId === 'serpent') {
    const coil = new THREE.Mesh(new THREE.TorusKnotGeometry(0.24, 0.07, 28, 6, 2, 3), glyphMat);
    emblem.add(coil);
  } else {
    // Lotus triad petals
    for (let i = -1; i <= 1; i++) {
      const petal = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.52, 6), glyphMat);
      petal.position.set(i * 0.2, i === 0 ? 0.06 : -0.04, 0);
      petal.rotation.z = -i * 0.45;
      emblem.add(petal);
    }
  }

  group.add(emblem);
  return group;
}


