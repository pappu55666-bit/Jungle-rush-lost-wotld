import * as THREE from 'three';

export interface ProceduralTextureSet {
  stoneColor: THREE.CanvasTexture;
  stoneBump: THREE.CanvasTexture;
  jungleGroundColor: THREE.CanvasTexture;
  barkColor: THREE.CanvasTexture;
  waterNormal: THREE.CanvasTexture;
  shadowDisc: THREE.CanvasTexture;
}

function makeCanvas(size: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

export function createProceduralTextures(maxAnisotropy: number): ProceduralTextureSet {
  // 1. Carved Ancient Temple Stone (Albedo + Bump)
  const [stoneCanvas, sCtx] = makeCanvas(256);
  const [bumpCanvas, bCtx] = makeCanvas(256);

  sCtx.fillStyle = '#8b836f';
  sCtx.fillRect(0, 0, 256, 256);
  bCtx.fillStyle = '#888888';
  bCtx.fillRect(0, 0, 256, 256);

  // Masonry blocks & mossy mortar seams
  const rows = 4;
  const rowH = 256 / rows;
  for (let r = 0; r < rows; r++) {
    const cols = 3;
    const colW = 256 / cols;
    const offset = (r % 2) * (colW * 0.5);
    for (let c = -1; c <= cols; c++) {
      const x = c * colW + offset;
      const y = r * rowH;
      const shade = 126 + ((r * 17 + c * 31) % 28);
      sCtx.fillStyle = `rgb(${shade}, ${shade - 8}, ${shade - 22})`;
      sCtx.fillRect(x + 3, y + 3, colW - 6, rowH - 6);

      bCtx.fillStyle = `rgb(${150 + ((r + c) % 3) * 18}, ${150 + ((r + c) % 3) * 18}, ${150 + ((r + c) % 3) * 18})`;
      bCtx.fillRect(x + 3, y + 3, colW - 6, rowH - 6);

      // Carved inner border detail
      sCtx.strokeStyle = 'rgba(65, 58, 42, 0.45)';
      sCtx.lineWidth = 2;
      sCtx.strokeRect(x + 10, y + 10, colW - 20, rowH - 20);
      bCtx.strokeStyle = '#505050';
      bCtx.lineWidth = 2;
      bCtx.strokeRect(x + 10, y + 10, colW - 20, rowH - 20);
    }
    // Mortar line
    sCtx.fillStyle = '#3b4a33';
    sCtx.fillRect(0, r * rowH - 2, 256, 4);
    bCtx.fillStyle = '#262626';
    bCtx.fillRect(0, r * rowH - 2, 256, 4);
  }

  // Subtle surface speckles
  for (let i = 0; i < 450; i++) {
    const px = (i * 73) % 256;
    const py = (i * 137) % 256;
    sCtx.fillStyle = i % 3 === 0 ? 'rgba(42, 74, 38, 0.25)' : 'rgba(255, 240, 210, 0.1)';
    sCtx.fillRect(px, py, 3, 3);
  }

  const stoneColor = new THREE.CanvasTexture(stoneCanvas);
  stoneColor.colorSpace = THREE.SRGBColorSpace;
  stoneColor.wrapS = stoneColor.wrapT = THREE.RepeatWrapping;
  stoneColor.repeat.set(2, 4);
  stoneColor.anisotropy = maxAnisotropy;

  const stoneBump = new THREE.CanvasTexture(bumpCanvas);
  stoneBump.wrapS = stoneBump.wrapT = THREE.RepeatWrapping;
  stoneBump.repeat.set(2, 4);
  stoneBump.anisotropy = maxAnisotropy;

  // 2. Jungle Forest Floor
  const [groundCanvas, gCtx] = makeCanvas(256);
  gCtx.fillStyle = '#2b5933';
  gCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 650; i++) {
    const x = (i * 97) % 256;
    const y = (i * 53) % 256;
    gCtx.fillStyle = i % 2 === 0 ? 'rgba(72, 134, 58, 0.35)' : 'rgba(28, 45, 22, 0.35)';
    gCtx.beginPath();
    gCtx.arc(x, y, 2 + (i % 5), 0, Math.PI * 2);
    gCtx.fill();
  }
  const jungleGroundColor = new THREE.CanvasTexture(groundCanvas);
  jungleGroundColor.colorSpace = THREE.SRGBColorSpace;
  jungleGroundColor.wrapS = jungleGroundColor.wrapT = THREE.RepeatWrapping;
  jungleGroundColor.repeat.set(6, 6);
  jungleGroundColor.anisotropy = maxAnisotropy;

  // 3. Wood Bark Texture
  const [barkCanvas, kCtx] = makeCanvas(128);
  kCtx.fillStyle = '#5a3d28';
  kCtx.fillRect(0, 0, 128, 128);
  for (let x = 0; x < 128; x += 6) {
    kCtx.fillStyle = x % 12 === 0 ? '#432b1a' : '#6c4b32';
    kCtx.fillRect(x, 0, 3, 128);
  }
  const barkColor = new THREE.CanvasTexture(barkCanvas);
  barkColor.colorSpace = THREE.SRGBColorSpace;
  barkColor.wrapS = barkColor.wrapT = THREE.RepeatWrapping;
  barkColor.anisotropy = maxAnisotropy;

  // 4. Water Ripples (linear bump/roughness)
  const [waterCanvas, wCtx] = makeCanvas(128);
  wCtx.fillStyle = '#808080';
  wCtx.fillRect(0, 0, 128, 128);
  for (let y = 0; y < 128; y += 8) {
    wCtx.strokeStyle = y % 16 === 0 ? '#b8b8b8' : '#585858';
    wCtx.lineWidth = 2;
    wCtx.beginPath();
    wCtx.moveTo(0, y);
    wCtx.bezierCurveTo(42, y + 5, 84, y - 5, 128, y);
    wCtx.stroke();
  }
  const waterNormal = new THREE.CanvasTexture(waterCanvas);
  waterNormal.wrapS = waterNormal.wrapT = THREE.RepeatWrapping;
  waterNormal.repeat.set(3, 6);

  // 5. Soft Radial Contact Shadow Disc
  const [discCanvas, dCtx] = makeCanvas(128);
  const grad = dCtx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.58)');
  grad.addColorStop(0.6, 'rgba(0, 0, 0, 0.25)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  dCtx.fillStyle = grad;
  dCtx.fillRect(0, 0, 128, 128);
  const shadowDisc = new THREE.CanvasTexture(discCanvas);
  shadowDisc.colorSpace = THREE.SRGBColorSpace;

  return {
    stoneColor,
    stoneBump,
    jungleGroundColor,
    barkColor,
    waterNormal,
    shadowDisc,
  };
}
