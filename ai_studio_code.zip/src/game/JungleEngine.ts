import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { audioEngine } from './audio';
import { BIOMES, CHARACTERS, MISSIONS } from './catalog';
import {
  buildExplorerRig,
  buildFernRockGroup,
  buildObstacleMesh,
  buildPalmTreeGroup,
  buildPickupMesh,
  buildRuneTabletMesh,
  buildSecretPortalMesh,
  buildSentinelBoss,
  buildTemplePillarGroup,
  buildTempleVistaBackdrop,
  type ExplorerRig,
} from './models';
import { RUNE_META, RUNE_ORDER, advanceCipherStep, getMysteryChapter } from './mysteries';
import {
  LANE_WIDTH,
  activateCharacterAbility,
  applyObstacleHit,
  calculatePickupScore,
  checkObstacleCollision,
  clampLane,
  computeRunSpeed,
  createInitialPlayerState,
  getBiomeForDistance,
  getLaneCenterX,
  releaseJumpEarly,
  stepPlayerPhysics,
  triggerJump,
  triggerSlide,
} from './rules';
import { createProceduralTextures, type ProceduralTextureSet } from './textures';
import type {
  BiomeId,
  CharacterId,
  GameScreenState,
  GraphicsPreset,
  ObstacleBox,
  ObstacleKind,
  PickupKind,
  PlayerPhysicsState,
  RuneSymbolId,
  RunHudSnapshot,
  RunOutcomeSnapshot,
  SaveData,
} from './types';

const TRACK_CHUNK_LEN = 22;
const NUM_CHUNKS = 8;
const PARTICLE_POOL_SIZE = 96;

interface PickupEntity {
  id: number;
  kind: PickupKind;
  lane: number;
  x: number;
  y: number;
  z: number;
  mesh: THREE.Group;
  collected: boolean;
}

interface PortalEntity {
  id: number;
  lane: number;
  z: number;
  mesh: THREE.Group;
  triggered: boolean;
}

interface RuneEntity {
  id: number;
  runeId: RuneSymbolId;
  lane: number;
  z: number;
  mesh: THREE.Group;
  collected: boolean;
}

interface ObstacleEntity {
  box: ObstacleBox;
  mesh: THREE.Group;
}

interface TrackChunk {
  group: THREE.Group;
  zStart: number; // negative Z center
  biomeId: BiomeId;
  groundMat: THREE.MeshStandardMaterial;
  roadMat: THREE.MeshStandardMaterial;
  waterMat: THREE.MeshStandardMaterial;
  foliageMeshes: THREE.Object3D[];
}

interface ParticleSlot {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  scale: number;
  color: THREE.Color;
}

export interface EngineCallbacks {
  onHudUpdate: (hud: RunHudSnapshot) => void;
  onGameOver: (outcome: RunOutcomeSnapshot) => void;
  onStateRequest: (next: GameScreenState) => void;
  onMissionIncrement: (
    increments: Partial<Record<'distance' | 'coins' | 'relics' | 'slides' | 'jumps' | 'secretRooms' | 'bosses', number>>
  ) => void;
  onMysterySolved: (chapterId: string) => void;
}

// Reusable scratch math objects (zero GC inside animation loop)
const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _color = new THREE.Color();
const _targetSky = new THREE.Color();
const _targetFog = new THREE.Color();
const _targetGround = new THREE.Color();
const _targetStone = new THREE.Color();
const _targetWater = new THREE.Color();

export class JungleEngine {
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private isSoftwareGl = false;

  private sunLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;
  private textures!: ProceduralTextureSet;
  private playerRig!: ExplorerRig;
  private bossGroup!: THREE.Group;
  private vistaGroup!: THREE.Group;

  private chunks: TrackChunk[] = [];
  private obstacles: ObstacleEntity[] = [];
  private pickups: PickupEntity[] = [];
  private portals: PortalEntity[] = [];
  private runes: RuneEntity[] = [];
  private nextEntityId = 1;

  // Pooled particle system
  private particleMesh!: THREE.InstancedMesh;
  private particles: ParticleSlot[] = [];
  private particleCursor = 0;

  // Simulation state
  private gameState: GameScreenState = 'title';
  private saveData: SaveData;
  private player: PlayerPhysicsState = createInitialPlayerState();
  private playerZ = 0; // Runs along -Z
  private distance = 0;
  private score = 0;
  private runCoins = 0;
  private runRelics = 0;
  private combo = 0;
  private comboTimer = 0;
  private bossesCleared = 0;
  private secretRoomsFound = 0;
  private revivedUsed = false;
  private currentBiome: BiomeId = 'emerald-canopy';
  private nextSpawnZ = -48;
  private lastChunkZ = 0;

  // Ancient Mystery Cipher state
  private mysteryStepIndex = 0;
  private mysteryBannerText: string | null = null;
  private mysteryBannerTimer = 0;
  private nextRuneDistance = 55;

  // Boss state
  private bossActive = false;
  private bossHp = 0;
  private bossMaxHp = 3;
  private bossTimer = 0;
  private bossAttackTimer = 0;
  private bossTelegraphLane: number | null = null;
  private nextBossDistance = 420;

  // Juice & Camera
  private hitstopTimer = 0;
  private trauma = 0;
  private squashY = 1;
  private squashXZ = 1;
  private stridePhase = 0;
  private currentFov = 58;
  private hitFlashTimer = 0;
  private hudEmitAccum = 0;
  private missionDistAccum = 0;
  private missionCoinAccum = 0;

  // Loop & Input
  private frameId = 0;
  private disposed = false;
  private lastTime = 0;
  private elapsed = 0;
  private keysHeld = new Set<string>();
  private swipeStartX = 0;
  private swipeStartY = 0;
  private swipeConsumed = false;
  private resizeObserver: ResizeObserver | null = null;

  constructor(container: HTMLElement, initialSave: SaveData, callbacks: EngineCallbacks) {
    this.container = container;
    this.saveData = initialSave;
    this.callbacks = callbacks;

    this.initRendererAndScene();
    this.initPlayerAndBoss();
    this.initParticles();
    this.buildInitialTrack();
    this.applyCharacterAppearance();
    this.applyGraphicsPreset(initialSave.settings.graphicsPreset);
    this.bindInputs();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.lastTime = performance.now();
    this.loop();
  }

  private detectSoftwareWebGL(): boolean {
    try {
      const probe = document.createElement('canvas');
      const gl = probe.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    } catch {
      return true;
    }
  }

  private initRendererAndScene() {
    this.isSoftwareGl = this.detectSoftwareWebGL();
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: this.isSoftwareGl,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    const startBiome = BIOMES[this.saveData.selectedStartBiome];
    this.scene.background = new THREE.Color(startBiome.skyColor);
    this.scene.fog = new THREE.FogExp2(startBiome.fogColor, startBiome.fogDensity);

    // Studio environment map on all devices for rich metallic gold/crystal reflections
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    this.camera = new THREE.PerspectiveCamera(58, w / h, 0.2, 220);
    this.camera.position.set(4.5, 4.4, 8.5);
    this.camera.lookAt(0, 1.4, -10);

    // 3-point warm/cool outdoor jungle lighting rig
    this.hemiLight = new THREE.HemisphereLight(startBiome.ambientSky, startBiome.ambientGround, 0.85);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(startBiome.sunColor, startBiome.sunIntensity);
    this.sunLight.position.set(16, 28, 12);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.set(1024, 1024);
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 90;
    const d = 24;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.02;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    const rimLight = new THREE.DirectionalLight(0x8be8d8, 0.55);
    rimLight.position.set(-14, 10, -24);
    this.scene.add(rimLight);

    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.textures = createProceduralTextures(maxAniso);

    // ResizeObserver for crisp layout on any Android aspect ratio
    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);
    window.addEventListener('resize', this.handleResize);
  }

  private initPlayerAndBoss() {
    this.playerRig = buildExplorerRig(this.textures.shadowDisc);
    this.scene.add(this.playerRig.root);

    this.bossGroup = buildSentinelBoss(this.textures);
    this.bossGroup.visible = false;
    this.scene.add(this.bossGroup);

    this.vistaGroup = buildTempleVistaBackdrop(this.textures);
    this.vistaGroup.position.set(0, -0.5, -135);
    this.scene.add(this.vistaGroup);
  }

  private initParticles() {
    const geo = new THREE.OctahedronGeometry(0.14, 0);
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.particleMesh = new THREE.InstancedMesh(geo, mat, PARTICLE_POOL_SIZE);
    this.particleMesh.frustumCulled = false;
    this.particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      this.particles.push({
        active: false,
        x: 0,
        y: -50,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 1,
        scale: 0,
        color: new THREE.Color(0xffd24a),
      });
      _mat4.makeScale(0, 0, 0);
      this.particleMesh.setMatrixAt(i, _mat4);
      this.particleMesh.setColorAt(i, _color.setHex(0xffd24a));
    }
    this.particleMesh.instanceMatrix.needsUpdate = true;
    if (this.particleMesh.instanceColor) this.particleMesh.instanceColor.needsUpdate = true;
    this.scene.add(this.particleMesh);
  }

  private spawnParticles(
    x: number,
    y: number,
    z: number,
    count: number,
    hexColor: number,
    speed = 4.5
  ) {
    for (let i = 0; i < count; i++) {
      const slot = this.particles[this.particleCursor];
      this.particleCursor = (this.particleCursor + 1) % PARTICLE_POOL_SIZE;
      slot.active = true;
      slot.x = x + (Math.random() - 0.5) * 0.4;
      slot.y = y + (Math.random() - 0.5) * 0.4;
      slot.z = z + (Math.random() - 0.5) * 0.4;
      slot.vx = (Math.random() - 0.5) * speed;
      slot.vy = 1.5 + Math.random() * speed * 0.8;
      slot.vz = (Math.random() - 0.5) * speed;
      slot.life = 0;
      slot.maxLife = 0.35 + Math.random() * 0.35;
      slot.scale = 0.7 + Math.random() * 0.8;
      slot.color.setHex(hexColor);
    }
  }

  private createTrackChunk(zCenter: number, biomeId: BiomeId): TrackChunk {
    const biome = BIOMES[biomeId];
    const group = new THREE.Group();
    group.position.set(0, 0, zCenter);

    // Wide outer jungle terrain floor so world never floats in a rectangular box
    const groundMat = new THREE.MeshStandardMaterial({
      map: this.textures.jungleGroundColor,
      color: biome.groundColor,
      roughness: 0.92,
      metalness: 0.02,
    });
    const terrain = new THREE.Mesh(new THREE.PlaneGeometry(140, TRACK_CHUNK_LEN + 0.4), groundMat);
    terrain.rotation.x = -Math.PI / 2;
    terrain.position.y = -0.35;
    terrain.receiveShadow = true;
    group.add(terrain);

    // Flowing side jungle river/waterfall channel
    const waterMat = new THREE.MeshStandardMaterial({
      color: biome.waterColor,
      bumpMap: this.textures.waterNormal,
      bumpScale: 0.08,
      roughness: 0.16,
      metalness: 0.3,
    });
    const riverLeft = new THREE.Mesh(new THREE.PlaneGeometry(10, TRACK_CHUNK_LEN + 0.3), waterMat);
    riverLeft.rotation.x = -Math.PI / 2;
    riverLeft.position.set(-10.5, -0.18, 0);
    group.add(riverLeft);

    const riverRight = new THREE.Mesh(new THREE.PlaneGeometry(10, TRACK_CHUNK_LEN + 0.3), waterMat);
    riverRight.rotation.x = -Math.PI / 2;
    riverRight.position.set(10.5, -0.18, 0);
    group.add(riverRight);

    // Ancient stone 3-lane causeway
    const roadMat = new THREE.MeshStandardMaterial({
      map: this.textures.stoneColor,
      bumpMap: this.textures.stoneBump,
      bumpScale: 0.05,
      color: biome.stoneColor,
      roughness: 0.78,
      metalness: 0.08,
    });
    const road = new THREE.Mesh(new THREE.BoxGeometry(9.2, 0.36, TRACK_CHUNK_LEN + 0.12), roadMat);
    road.position.y = -0.18;
    road.receiveShadow = true;
    group.add(road);

    // Carved stone curbs along causeway edges
    const curbMat = new THREE.MeshStandardMaterial({
      color: biome.accentColor,
      roughness: 0.45,
      metalness: 0.4,
    });
    const curbL = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.24, TRACK_CHUNK_LEN), curbMat);
    curbL.position.set(-4.65, 0.08, 0);
    group.add(curbL);
    const curbR = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.24, TRACK_CHUNK_LEN), curbMat);
    curbR.position.set(4.65, 0.08, 0);
    group.add(curbR);

    // Roadside foliage & temple pillars (natural perimeter)
    const foliageMeshes: THREE.Object3D[] = [];
    for (let side of [-1, 1]) {
      const palm = buildPalmTreeGroup(this.textures);
      palm.position.set(side * (6.2 + Math.random() * 2.5), -0.35, (Math.random() - 0.5) * 14);
      palm.scale.setScalar(0.9 + Math.random() * 0.35);
      palm.rotation.y = Math.random() * Math.PI * 2;
      group.add(palm);
      foliageMeshes.push(palm);

      const pillar = buildTemplePillarGroup(this.textures);
      pillar.position.set(side * 5.25, -0.1, (Math.random() - 0.5) * 10);
      pillar.scale.setScalar(0.85);
      group.add(pillar);
      foliageMeshes.push(pillar);

      const fernRock = buildFernRockGroup();
      fernRock.position.set(side * (7.8 + Math.random() * 4.5), -0.35, (Math.random() - 0.5) * 18);
      fernRock.rotation.y = Math.random() * Math.PI * 2;
      fernRock.scale.setScalar(0.8 + Math.random() * 0.5);
      group.add(fernRock);
      foliageMeshes.push(fernRock);
    }

    this.scene.add(group);
    return {
      group,
      zStart: zCenter,
      biomeId,
      groundMat,
      roadMat,
      waterMat,
      foliageMeshes,
    };
  }

  private buildInitialTrack() {
    for (let i = 0; i < NUM_CHUNKS; i++) {
      const zCenter = 12 - i * TRACK_CHUNK_LEN;
      const chunk = this.createTrackChunk(zCenter, this.saveData.selectedStartBiome);
      this.chunks.push(chunk);
      this.lastChunkZ = zCenter;
    }
    this.seedInitialRunway();
  }

  private seedInitialRunway() {
    // Clear opening stretch with welcoming coins so player always survives spawn
    for (let i = 0; i < 6; i++) {
      this.spawnPickup('gold-coin', 0, -14 - i * 3.0, 0.75);
    }
    this.nextSpawnZ = -40;
  }

  public updateSaveData(nextSave: SaveData) {
    this.saveData = nextSave;
    this.applyCharacterAppearance();
    this.applyGraphicsPreset(nextSave.settings.graphicsPreset);
  }

  public applyGraphicsPreset(preset: GraphicsPreset) {
    if (this.isSoftwareGl) {
      this.renderer.setPixelRatio(1);
      this.renderer.shadowMap.enabled = false;
      return;
    }
    if (preset === 'budget') {
      this.renderer.setPixelRatio(1);
      this.renderer.shadowMap.enabled = false;
      this.sunLight.castShadow = false;
    } else if (preset === 'balanced') {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
      this.renderer.shadowMap.enabled = true;
      this.sunLight.castShadow = true;
    } else {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.renderer.shadowMap.enabled = true;
      this.sunLight.castShadow = true;
    }
  }

  private applyCharacterAppearance() {
    const charId: CharacterId = this.saveData.selectedCharacter;
    const charDef = CHARACTERS[charId];
    const costumeId = this.saveData.selectedCostumes[charId] ?? charDef.costumes[0].id;
    const costume = charDef.costumes.find((c) => c.id === costumeId) ?? charDef.costumes[0];
    this.playerRig.primaryMat.color.setHex(costume.primaryColor);
    this.playerRig.accentMat.color.setHex(costume.accentColor);
    this.playerRig.trimMat.color.setHex(costume.trimColor);
  }

  public setGameState(next: GameScreenState) {
    this.gameState = next;
    document.body.dataset.state = next;
    if (next === 'playing') {
      this.keysHeld.clear();
      audioEngine.unlock();
      audioEngine.startAmbientPulse();
    } else {
      audioEngine.stopAmbientPulse();
    }
  }

  public startNewRun(startBiome?: BiomeId) {
    if (startBiome) {
      this.saveData = { ...this.saveData, selectedStartBiome: startBiome };
    }
    this.clearDynamicEntities();
    this.player = createInitialPlayerState();
    this.playerZ = 0;
    this.distance = 0;
    this.score = 0;
    this.runCoins = 0;
    this.runRelics = 0;
    this.combo = 0;
    this.comboTimer = 0;
    this.bossesCleared = 0;
    this.secretRoomsFound = 0;
    this.revivedUsed = false;
    this.bossActive = false;
    this.bossGroup.visible = false;
    this.bossTelegraphLane = null;
    this.nextBossDistance = 380;
    this.currentBiome = this.saveData.selectedStartBiome;
    this.hitstopTimer = 0;
    this.trauma = 0;
    this.hitFlashTimer = 0;
    this.missionDistAccum = 0;
    this.missionCoinAccum = 0;
    this.mysteryStepIndex = 0;
    this.mysteryBannerText = null;
    this.mysteryBannerTimer = 0;
    this.nextRuneDistance = 52;

    // Reposition track chunks cleanly from z = +12 forward
    for (let i = 0; i < this.chunks.length; i++) {
      const zCenter = 12 - i * TRACK_CHUNK_LEN;
      this.chunks[i].zStart = zCenter;
      this.chunks[i].group.position.z = zCenter;
      this.lastChunkZ = zCenter;
    }

    this.playerRig.root.position.set(0, 0, 0);
    this.applyCharacterAppearance();
    this.seedInitialRunway();
    this.setGameState('playing');
    this.emitHud();
  }

  public reviveRun() {
    this.revivedUsed = true;
    this.player.hearts = 2;
    this.player.invulnTimer = 3.0;
    this.player.shieldActive = true;
    // Clear immediate obstacles ahead so revive is always fair
    for (const obs of this.obstacles) {
      if (Math.abs(obs.box.z - this.playerZ) < 18) {
        obs.box.hit = true;
        obs.mesh.visible = false;
      }
    }
    this.setGameState('playing');
    audioEngine.playPowerup();
    this.emitHud();
  }

  private clearDynamicEntities() {
    for (const o of this.obstacles) this.scene.remove(o.mesh);
    this.obstacles = [];
    for (const p of this.pickups) this.scene.remove(p.mesh);
    this.pickups = [];
    for (const pr of this.portals) this.scene.remove(pr.mesh);
    this.portals = [];
    for (const r of this.runes) this.scene.remove(r.mesh);
    this.runes = [];
  }

  // Public Input Actions (for both keyboard and Android touch buttons)
  public moveLeft() {
    if (this.gameState !== 'playing') return;
    const prev = this.player.lane;
    this.player.lane = clampLane(this.player.lane - 1);
    if (this.player.lane !== prev) audioEngine.playLaneSwitch();
  }

  public moveRight() {
    if (this.gameState !== 'playing') return;
    const prev = this.player.lane;
    this.player.lane = clampLane(this.player.lane + 1);
    if (this.player.lane !== prev) audioEngine.playLaneSwitch();
  }

  public jump() {
    if (this.gameState !== 'playing') return;
    const jumped = triggerJump(this.player);
    if (jumped) {
      this.squashY = 1.2;
      this.squashXZ = 0.85;
      this.spawnParticles(this.player.x, 0.1, this.playerZ, 5, 0xd9c28b, 3.0);
      audioEngine.playJump();
      this.callbacks.onMissionIncrement({ jumps: 1 });
    }
  }

  public slide() {
    if (this.gameState !== 'playing') return;
    if (triggerSlide(this.player)) {
      this.squashY = 0.65;
      this.squashXZ = 1.25;
      this.spawnParticles(this.player.x, 0.15, this.playerZ, 5, 0x8cb87a, 3.2);
      audioEngine.playSlide();
      this.callbacks.onMissionIncrement({ slides: 1 });
    }
  }

  public triggerSpecialAbility() {
    if (this.gameState !== 'playing') return;
    const ok = activateCharacterAbility(this.player, this.saveData.selectedCharacter);
    if (ok) {
      this.trauma = Math.min(1, this.trauma + 0.35);
      this.spawnParticles(this.player.x, 1.0, this.playerZ, 18, 0xffd24a, 6.5);
      audioEngine.playAbility();
      if (this.saveData.selectedCharacter === 'torin') {
        // Shatter nearby obstacles ahead into bonus coins
        for (const obs of this.obstacles) {
          if (obs.box.z < this.playerZ && obs.box.z > this.playerZ - 30) {
            obs.box.hit = true;
            obs.mesh.visible = false;
            this.spawnParticles(getLaneCenterX(obs.box.lane), 1.0, obs.box.z, 10, 0xff9f40, 5.5);
            this.runCoins += 2;
            this.score += 35;
          }
        }
      }
      this.emitHud();
    }
  }

  private bindInputs() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    document.addEventListener('visibilitychange', this.onVisibilityChange);

    const dom = this.renderer.domElement;
    dom.addEventListener('touchstart', this.onTouchStart, { passive: true });
    dom.addEventListener('touchmove', this.onTouchMove, { passive: false });
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const code = e.code;
    if (this.keysHeld.has(code)) return;
    this.keysHeld.add(code);

    if (this.gameState === 'playing') {
      if (code === 'ArrowLeft' || code === 'KeyA') {
        e.preventDefault();
        this.moveLeft();
      } else if (code === 'ArrowRight' || code === 'KeyD') {
        e.preventDefault();
        this.moveRight();
      } else if (code === 'ArrowUp' || code === 'KeyW' || code === 'Space') {
        e.preventDefault();
        this.jump();
      } else if (code === 'ArrowDown' || code === 'KeyS') {
        e.preventDefault();
        this.slide();
      } else if (code === 'KeyE' || code === 'ShiftLeft') {
        e.preventDefault();
        this.triggerSpecialAbility();
      } else if (code === 'Escape' || code === 'KeyP') {
        e.preventDefault();
        this.callbacks.onStateRequest('paused');
      }
    } else if (this.gameState === 'paused' && (code === 'Escape' || code === 'KeyP')) {
      e.preventDefault();
      this.callbacks.onStateRequest('playing');
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keysHeld.delete(e.code);
    if (
      this.gameState === 'playing' &&
      (e.code === 'ArrowUp' || e.code === 'KeyW' || e.code === 'Space')
    ) {
      releaseJumpEarly(this.player);
    }
  };

  private onWindowBlur = () => {
    this.keysHeld.clear();
  };

  private onVisibilityChange = () => {
    if (document.hidden) {
      this.keysHeld.clear();
    }
  };

  private onTouchStart = (e: TouchEvent) => {
    if (this.gameState !== 'playing' || e.touches.length === 0) return;
    this.swipeStartX = e.touches[0].clientX;
    this.swipeStartY = e.touches[0].clientY;
    this.swipeConsumed = false;
  };

  private onTouchMove = (e: TouchEvent) => {
    if (this.gameState !== 'playing' || this.swipeConsumed || e.touches.length === 0) return;
    const dx = e.touches[0].clientX - this.swipeStartX;
    const dy = e.touches[0].clientY - this.swipeStartY;
    const threshold = 26;
    if (Math.abs(dx) < threshold && Math.abs(dy) < threshold) return;

    e.preventDefault();
    this.swipeConsumed = true;
    if (Math.abs(dx) > Math.abs(dy)) {
      if (dx < 0) this.moveLeft();
      else this.moveRight();
    } else {
      if (dy < 0) this.jump();
      else this.slide();
    }
  };

  private spawnObstacle(kind: ObstacleKind, lane: number, z: number) {
    const mesh = buildObstacleMesh(kind, this.textures);
    mesh.position.set(getLaneCenterX(lane), 0, z);
    this.scene.add(mesh);

    const box: ObstacleBox = {
      id: this.nextEntityId++,
      kind,
      lane,
      z,
      width: kind === 'stone-arch' ? 2.1 : kind === 'temple-pit' ? 2.0 : 1.55,
      height: kind === 'fallen-log' ? 0.88 : kind === 'stone-arch' ? 1.5 : 2.1,
      depth: kind === 'temple-pit' ? 2.2 : 0.95,
      clearanceBottom: kind === 'stone-arch' ? 1.05 : 0,
      velocityZ: kind === 'rolling-boulder' ? 7.5 : 0,
      hit: false,
    };

    this.obstacles.push({ box, mesh });
  }

  private spawnPickup(kind: PickupKind, lane: number, z: number, y = 0.75) {
    const mesh = buildPickupMesh(kind);
    const x = getLaneCenterX(lane);
    mesh.position.set(x, y, z);
    this.scene.add(mesh);
    this.pickups.push({
      id: this.nextEntityId++,
      kind,
      lane,
      x,
      y,
      z,
      mesh,
      collected: false,
    });
  }

  private spawnPortal(lane: number, z: number) {
    const mesh = buildSecretPortalMesh(this.textures);
    mesh.position.set(getLaneCenterX(lane), 0, z);
    this.scene.add(mesh);
    this.portals.push({
      id: this.nextEntityId++,
      lane,
      z,
      mesh,
      triggered: false,
    });
  }

  private generateNextPatterns() {
    while (this.nextSpawnZ > this.playerZ - 115) {
      const z = this.nextSpawnZ;
      const inSecret = this.player.secretRoomTimer > 0;

      if (inSecret) {
        // Hidden Treasure Room: dense golden coin arcs & emerald relics, safe side paths!
        const lane = Math.floor(Math.random() * 3) - 1;
        for (let i = 0; i < 5; i++) {
          this.spawnPickup(i === 2 ? 'emerald-relic' : 'gold-coin', lane, z - i * 2.4, 0.85);
        }
        this.nextSpawnZ -= 18;
        continue;
      }

      // Difficulty scaling
      const diff = Math.min(1, this.distance / 1400);
      const safeLane = Math.floor(Math.random() * 3) - 1;
      const numObstacles = diff > 0.45 && Math.random() < 0.48 ? 2 : 1;
      const lanes = [-1, 0, 1];
      const kinds: ObstacleKind[] = [
        'fallen-log',
        'stone-arch',
        'spike-totem',
        'rolling-boulder',
        'temple-pit',
      ];

      let placed = 0;
      for (const lane of lanes) {
        if (lane === safeLane && numObstacles < 3) continue;
        if (placed >= numObstacles) break;
        const kind = kinds[Math.floor(Math.random() * (diff > 0.2 ? kinds.length : 3))];
        this.spawnObstacle(kind, lane, z);
        if (kind === 'fallen-log' || kind === 'temple-pit') {
          // Rewarding jump coin arc right over the obstacle!
          this.spawnPickup('gold-coin', lane, z, 2.05);
        }
        placed++;
      }

      // Coin ribbon along the safe lane
      const coinCount = 3 + Math.floor(Math.random() * 3);
      for (let i = 0; i < coinCount; i++) {
        this.spawnPickup('gold-coin', safeLane, z - 4 - i * 2.6, 0.78);
      }

      // Occasional Emerald Relic or Powerup Orb
      const roll = Math.random();
      if (roll < 0.18) {
        this.spawnPickup('emerald-relic', (safeLane + 2) % 3 - 1, z - 8, 1.0);
      } else if (roll < 0.28) {
        const powerKinds: PickupKind[] = ['magnet-orb', 'shield-orb', 'multiplier-orb'];
        const pk = powerKinds[Math.floor(Math.random() * powerKinds.length)];
        this.spawnPickup(pk, safeLane, z - 12, 0.95);
      }

      // Secret Lost World Portal every ~260m
      if (this.distance > 120 && Math.random() < 0.08 && this.portals.length === 0) {
        this.spawnPortal(safeLane, z - 16);
      }

      // Ancient Mystery Rune Tablets (spawn next cipher symbol + decoy on higher chapters)
      const projectedDist = Math.abs(z);
      if (projectedDist >= this.nextRuneDistance) {
        const chapter = getMysteryChapter(this.saveData.activeMysteryId);
        const targetRune = chapter.sequence[this.mysteryStepIndex % chapter.sequence.length];
        this.spawnRuneTablet(targetRune, safeLane, z - 6);

        if (chapter.chapterNumber >= 2) {
          const decoyPool = RUNE_ORDER.filter((r) => r !== targetRune);
          const decoyRune = decoyPool[Math.floor(Math.random() * decoyPool.length)];
          const decoyLane = safeLane === 0 ? 1 : 0;
          this.spawnRuneTablet(decoyRune, decoyLane, z - 6);
        }
        this.nextRuneDistance = projectedDist + 38;
      }

      const gap = Math.max(16, 26 - diff * 8);
      this.nextSpawnZ -= gap;
    }
  }

  private spawnRuneTablet(runeId: RuneSymbolId, lane: number, z: number) {
    const mesh = buildRuneTabletMesh(runeId, this.textures);
    mesh.position.set(getLaneCenterX(lane), 0, z);
    this.scene.add(mesh);
    this.runes.push({
      id: this.nextEntityId++,
      runeId,
      lane,
      z,
      mesh,
      collected: false,
    });
  }

  private updateAtmosphere(dt: number) {
    const targetBiomeId =
      this.player.secretRoomTimer > 0
        ? 'lost-world'
        : getBiomeForDistance(this.distance, this.saveData.selectedStartBiome);
    this.currentBiome = targetBiomeId;
    const b = BIOMES[targetBiomeId];

    const alpha = 1 - Math.exp(-2.2 * dt);
    _targetSky.setHex(b.skyColor);
    _targetFog.setHex(b.fogColor);
    (this.scene.background as THREE.Color).lerp(_targetSky, alpha);
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color.lerp(_targetFog, alpha);
      this.scene.fog.density += (b.fogDensity - this.scene.fog.density) * alpha;
    }
    this.sunLight.color.lerp(_targetSky.setHex(b.sunColor), alpha);
    this.sunLight.intensity += (b.sunIntensity - this.sunLight.intensity) * alpha;

    _targetGround.setHex(b.groundColor);
    _targetStone.setHex(b.stoneColor);
    _targetWater.setHex(b.waterColor);
    for (const chunk of this.chunks) {
      chunk.groundMat.color.lerp(_targetGround, alpha);
      chunk.roadMat.color.lerp(_targetStone, alpha);
      chunk.waterMat.color.lerp(_targetWater, alpha);
    }
    this.textures.waterNormal.offset.y -= dt * 0.45;
  }

  private updateBoss(dt: number) {
    if (!this.bossActive && this.distance >= this.nextBossDistance) {
      this.bossActive = true;
      this.bossHp = 3;
      this.bossMaxHp = 3;
      this.bossTimer = 16;
      this.bossAttackTimer = 2.2;
      this.bossTelegraphLane = null;
      this.bossGroup.visible = true;
      audioEngine.playBossTelegraph();
    }

    if (!this.bossActive) return;

    this.bossTimer -= dt;
    // Float Stone Sentinel menacingly 24m ahead of player
    this.bossGroup.position.set(
      Math.sin(this.elapsed * 1.4) * 1.6,
      0.5 + Math.sin(this.elapsed * 3.1) * 0.35,
      this.playerZ - 24
    );
    const halo = this.bossGroup.getObjectByName('bossHalo');
    if (halo) halo.rotation.z += dt * 1.8;

    this.bossAttackTimer -= dt;
    if (this.bossAttackTimer <= 0.7 && this.bossTelegraphLane === null) {
      // Windup telegraph: pick target lane
      this.bossTelegraphLane = this.player.lane;
      audioEngine.playBossTelegraph();
    }
    if (this.bossAttackTimer <= 0 && this.bossTelegraphLane !== null) {
      // Fire rolling temple boulder down the telegraphed lane
      this.spawnObstacle('rolling-boulder', this.bossTelegraphLane, this.playerZ - 22);
      this.bossTelegraphLane = null;
      this.bossAttackTimer = 2.4;
      this.bossHp -= 1;
      this.spawnParticles(this.bossGroup.position.x, 2.5, this.bossGroup.position.z, 12, 0xff7033, 6);
    }

    if (this.bossTimer <= 0 || this.bossHp <= 0) {
      this.bossActive = false;
      this.bossGroup.visible = false;
      this.bossTelegraphLane = null;
      this.bossesCleared += 1;
      this.nextBossDistance = this.distance + 450;
      this.score += 350;
      this.runCoins += 25;
      audioEngine.playRelic();
      this.callbacks.onMissionIncrement({ bosses: 1, coins: 25 });
    }
  }

  private updatePlaying(dt: number) {
    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    const charDef = CHARACTERS[this.saveData.selectedCharacter];
    const runSpeed = computeRunSpeed(
      this.distance,
      charDef.speedBonus + (this.player.abilityActiveTimer > 0 && this.saveData.selectedCharacter === 'kaelen' ? 0.35 : 0),
      this.player.secretRoomTimer > 0
    );

    const dz = runSpeed * dt;
    this.playerZ -= dz;
    this.distance += dz;
    this.score += dz * (this.player.multiplierTimer > 0 ? 3 : 1.5);
    this.missionDistAccum += dz;
    if (this.missionDistAccum >= 10) {
      const whole = Math.floor(this.missionDistAccum);
      this.missionDistAccum -= whole;
      this.callbacks.onMissionIncrement({ distance: whole });
    }

    // Physics step
    const step = stepPlayerPhysics(this.player, dt, 0);
    if (step.landed) {
      this.squashY = 0.78;
      this.squashXZ = 1.22;
      this.spawnParticles(this.player.x, 0.08, this.playerZ, 6, 0xb8a374, 3.2);
      audioEngine.playLand();
    }
    if (step.jumpedFromBuffer) {
      this.squashY = 1.2;
      this.squashXZ = 0.85;
      audioEngine.playJump();
    }

    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) this.combo = 0;
    }

    // Recycle passed track chunks
    for (const chunk of this.chunks) {
      if (chunk.zStart > this.playerZ + TRACK_CHUNK_LEN * 1.4) {
        this.lastChunkZ -= TRACK_CHUNK_LEN;
        chunk.zStart = this.lastChunkZ;
        chunk.group.position.z = this.lastChunkZ;
      }
    }

    this.generateNextPatterns();
    this.updateBoss(dt);

    // Update Obstacles & Collisions
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obs = this.obstacles[i];
      if (obs.box.velocityZ !== 0) {
        obs.box.z += obs.box.velocityZ * dt;
        obs.mesh.position.z = obs.box.z;
        const body = obs.mesh.getObjectByName('boulderBody');
        if (body) body.rotation.x += dt * 7;
      }

      if (checkObstacleCollision(this.player, this.playerZ, obs.box)) {
        obs.box.hit = true;
        const outcome = applyObstacleHit(this.player);
        if (outcome === 'shield-broken' || outcome === 'damaged' || outcome === 'defeated') {
          this.hitstopTimer = 0.055;
          this.trauma = Math.min(1, this.trauma + 0.65);
          this.hitFlashTimer = 0.14;
          this.combo = 0;
          this.spawnParticles(this.player.x, 1.0, this.playerZ, 20, 0xff5a36, 7.0);
          audioEngine.playHit(outcome === 'defeated');
          obs.mesh.visible = false;

          if (outcome === 'defeated') {
            this.finishRun(false);
            return;
          }
        }
      }

      if (obs.box.z > this.playerZ + 18) {
        this.scene.remove(obs.mesh);
        this.obstacles.splice(i, 1);
      }
    }

    // Update Pickups & Magnet pull
    const magnetRange = this.player.magnetTimer > 0 ? 7.5 + charDef.magnetRangeBonus : 1.15;
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.mesh.rotation.y += dt * 3.2;

      const dx = this.player.x - p.x;
      const dy = this.player.y + 0.9 - p.y;
      const dzp = this.playerZ - p.z;
      const distSq = dx * dx + dy * dy + dzp * dzp;

      if (!p.collected && this.player.magnetTimer > 0 && distSq < magnetRange * magnetRange) {
        const pull = 1 - Math.exp(-12 * dt);
        p.x += dx * pull;
        p.y += dy * pull;
        p.z += dzp * pull;
        p.mesh.position.set(p.x, p.y, p.z);
      }

      if (!p.collected && distSq < 1.35 * 1.35) {
        p.collected = true;
        p.mesh.visible = false;
        if (p.kind === 'gold-coin' || p.kind === 'emerald-relic') {
          const gained = calculatePickupScore(
            p.kind,
            this.combo,
            this.player.multiplierTimer > 0
          );
          this.score += gained.points;
          this.runCoins += gained.coins;
          this.runRelics += gained.relics;
          this.combo += 1;
          this.comboTimer = 2.6;
          this.player.abilityCharge = Math.min(100, this.player.abilityCharge + gained.chargeGain);
          this.missionCoinAccum += gained.coins;
          if (this.missionCoinAccum >= 5) {
            const c = this.missionCoinAccum;
            this.missionCoinAccum = 0;
            this.callbacks.onMissionIncrement({ coins: c });
          }
          if (gained.relics > 0) {
            this.callbacks.onMissionIncrement({ relics: gained.relics });
            audioEngine.playRelic();
            this.spawnParticles(p.x, p.y, p.z, 14, 0x3ef0b4, 5.5);
          } else {
            audioEngine.playCoin(this.combo);
            this.spawnParticles(p.x, p.y, p.z, 5, 0xffd24a, 3.6);
          }
        } else {
          audioEngine.playPowerup();
          this.spawnParticles(p.x, p.y, p.z, 12, 0x62d9ff, 5);
          if (p.kind === 'magnet-orb') this.player.magnetTimer = 8.0;
          else if (p.kind === 'shield-orb') this.player.shieldActive = true;
          else if (p.kind === 'multiplier-orb') this.player.multiplierTimer = 8.0;
        }
      }

      if (p.collected || p.z > this.playerZ + 14) {
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
      }
    }

    // Secret Lost World Portals
    for (let i = this.portals.length - 1; i >= 0; i--) {
      const pr = this.portals[i];
      const vortex = pr.mesh.getObjectByName('portalVortex');
      if (vortex) vortex.rotation.z += dt * 3;
      if (
        !pr.triggered &&
        Math.abs(this.playerZ - pr.z) < 1.5 &&
        Math.abs(this.player.x - getLaneCenterX(pr.lane)) < 1.4
      ) {
        pr.triggered = true;
        this.player.secretRoomTimer = 7.5;
        this.secretRoomsFound += 1;
        this.score += 200;
        this.trauma = Math.min(1, this.trauma + 0.3);
        this.spawnParticles(this.player.x, 1.4, this.playerZ, 22, 0x3ef2d6, 7);
        audioEngine.playPortal();
        this.callbacks.onMissionIncrement({ secretRooms: 1 });
      }
      if (pr.z > this.playerZ + 16) {
        this.scene.remove(pr.mesh);
        this.portals.splice(i, 1);
      }
    }

    // Ancient Mystery Rune Tablets
    if (this.mysteryBannerTimer > 0) {
      this.mysteryBannerTimer -= dt;
      if (this.mysteryBannerTimer <= 0) this.mysteryBannerText = null;
    }

    for (let i = this.runes.length - 1; i >= 0; i--) {
      const r = this.runes[i];
      const emblem = r.mesh.getObjectByName('runeEmblem');
      if (emblem) emblem.rotation.y += dt * 2.5;
      const ring = r.mesh.getObjectByName('runeRing');
      if (ring) ring.rotation.z += dt * 1.1;

      if (
        !r.collected &&
        Math.abs(this.playerZ - r.z) < 1.35 &&
        Math.abs(this.player.x - getLaneCenterX(r.lane)) < 1.2
      ) {
        r.collected = true;
        r.mesh.visible = false;
        const chapter = getMysteryChapter(this.saveData.activeMysteryId);
        const stepRes = advanceCipherStep(chapter.sequence, this.mysteryStepIndex, r.runeId);
        this.mysteryStepIndex = stepRes.nextIndex;
        const runeMeta = RUNE_META[r.runeId];

        if (stepRes.completed) {
          this.score += 180;
          this.runCoins += 15;
          this.mysteryBannerText = `Mystery Solved: ${chapter.title}!`;
          this.mysteryBannerTimer = 3.2;
          this.spawnParticles(this.player.x, 1.4, this.playerZ, 22, runeMeta.colorHex, 7);
          audioEngine.playPortal();
          this.callbacks.onMysterySolved(chapter.id);
        } else if (stepRes.matched) {
          this.score += 50;
          this.mysteryBannerText = `Glyph Deciphered: ${runeMeta.name} (${this.mysteryStepIndex}/${chapter.sequence.length})`;
          this.mysteryBannerTimer = 1.6;
          this.spawnParticles(this.player.x, 1.2, this.playerZ, 12, runeMeta.colorHex, 5);
          audioEngine.playRelic();
        } else if (stepRes.reset) {
          this.mysteryBannerText = `Wrong Glyph (${runeMeta.name}) · Cipher Reset`;
          this.mysteryBannerTimer = 1.6;
          audioEngine.playLaneSwitch();
        }
        this.emitHud();
      }

      if (r.collected || r.z > this.playerZ + 14) {
        this.scene.remove(r.mesh);
        this.runes.splice(i, 1);
      }
    }

    // Animate Explorer rig synced to run distance
    this.stridePhase += dz * 0.65;
    this.animateExplorer(dt, true);
  }

  private animateExplorer(dt: number, running: boolean) {
    this.playerRig.root.position.set(this.player.x, this.player.y, this.playerZ);

    // Damp squash & stretch back to 1
    this.squashY = THREE.MathUtils.damp(this.squashY, 1, 14, dt);
    this.squashXZ = THREE.MathUtils.damp(this.squashXZ, 1, 14, dt);

    const sliding = this.player.slideTimer > 0 && this.player.grounded;
    if (sliding) {
      this.playerRig.bodyPivot.rotation.x = THREE.MathUtils.damp(
        this.playerRig.bodyPivot.rotation.x,
        -1.15,
        18,
        dt
      );
      this.playerRig.bodyPivot.position.y = THREE.MathUtils.damp(
        this.playerRig.bodyPivot.position.y,
        -0.45,
        18,
        dt
      );
    } else {
      const lean = (getLaneCenterX(this.player.lane) - this.player.x) * -0.14;
      this.playerRig.bodyPivot.rotation.z = THREE.MathUtils.damp(
        this.playerRig.bodyPivot.rotation.z,
        lean,
        14,
        dt
      );
      this.playerRig.bodyPivot.rotation.x = THREE.MathUtils.damp(
        this.playerRig.bodyPivot.rotation.x,
        running ? 0.14 : 0,
        12,
        dt
      );
      this.playerRig.bodyPivot.position.y = THREE.MathUtils.damp(
        this.playerRig.bodyPivot.position.y,
        running && this.player.grounded ? Math.abs(Math.sin(this.stridePhase)) * 0.12 : 0,
        18,
        dt
      );
    }

    this.playerRig.bodyPivot.scale.set(this.squashXZ, this.squashY, this.squashXZ);

    if (running && this.player.grounded && !sliding) {
      const swing = Math.sin(this.stridePhase) * 0.85;
      this.playerRig.leftLeg.rotation.x = swing;
      this.playerRig.rightLeg.rotation.x = -swing;
      this.playerRig.leftArm.rotation.x = -swing * 0.8;
      this.playerRig.rightArm.rotation.x = swing * 0.8;
    } else if (!this.player.grounded) {
      this.playerRig.leftLeg.rotation.x = 0.45;
      this.playerRig.rightLeg.rotation.x = -0.35;
      this.playerRig.leftArm.rotation.x = -0.8;
      this.playerRig.rightArm.rotation.x = -0.6;
    } else {
      this.playerRig.leftLeg.rotation.x = 0;
      this.playerRig.rightLeg.rotation.x = 0;
      this.playerRig.leftArm.rotation.x = Math.sin(this.elapsed * 2) * 0.08;
      this.playerRig.rightArm.rotation.x = -Math.sin(this.elapsed * 2) * 0.08;
    }

    // Shield & Ability visual rings
    this.playerRig.shieldSphere.visible = this.player.shieldActive;
    if (this.player.shieldActive) {
      this.playerRig.shieldSphere.rotation.y += dt * 1.4;
    }
    this.playerRig.auraRing.visible = this.player.abilityActiveTimer > 0;
    if (this.player.abilityActiveTimer > 0) {
      this.playerRig.auraRing.rotation.z += dt * 4;
    }

    // Hit flash / invulnerability blink
    if (this.hitFlashTimer > 0) {
      this.hitFlashTimer -= dt;
      this.playerRig.primaryMat.emissive.setHex(0xffffff);
      this.playerRig.primaryMat.emissiveIntensity = 0.85;
    } else {
      this.playerRig.primaryMat.emissive.setHex(0x000000);
      this.playerRig.primaryMat.emissiveIntensity = 0;
    }
    this.playerRig.bodyPivot.visible =
      this.player.invulnTimer <= 0 || Math.floor(this.elapsed * 18) % 2 === 0;
  }

  private updateParticles(dt: number) {
    let anyActive = false;
    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      const slot = this.particles[i];
      if (!slot.active) {
        _mat4.makeScale(0, 0, 0);
        this.particleMesh.setMatrixAt(i, _mat4);
        continue;
      }
      anyActive = true;
      slot.life += dt;
      if (slot.life >= slot.maxLife) {
        slot.active = false;
        _mat4.makeScale(0, 0, 0);
        this.particleMesh.setMatrixAt(i, _mat4);
        continue;
      }
      slot.vy -= 12 * dt;
      slot.x += slot.vx * dt;
      slot.y += slot.vy * dt;
      slot.z += slot.vz * dt;
      const t = 1 - slot.life / slot.maxLife;
      const s = slot.scale * t;
      _pos.set(slot.x, slot.y, slot.z);
      _quat.setFromAxisAngle(_scale.set(0, 1, 0), slot.life * 6);
      _scale.set(s, s, s);
      _mat4.compose(_pos, _quat, _scale);
      this.particleMesh.setMatrixAt(i, _mat4);
      this.particleMesh.setColorAt(i, slot.color);
    }
    if (anyActive) {
      this.particleMesh.instanceMatrix.needsUpdate = true;
      if (this.particleMesh.instanceColor) this.particleMesh.instanceColor.needsUpdate = true;
    }
  }

  private updateCamera(dt: number) {
    // Keep distant pyramid & waterfall horizon ahead of the player
    this.vistaGroup.position.z = this.playerZ - 140;

    if (this.gameState === 'title') {
      // Atmospheric Live-World Camera Pan framing Explorer & Temple Horizon on center-right
      const panX = 1.6 + Math.sin(this.elapsed * 0.35) * 2.2;
      const panY = 3.1 + Math.sin(this.elapsed * 0.55) * 0.35;
      const camAlpha = 1 - Math.exp(-3 * dt);
      this.camera.position.x += (panX - this.camera.position.x) * camAlpha;
      this.camera.position.y += (panY - this.camera.position.y) * camAlpha;
      this.camera.position.z += (6.4 - this.camera.position.z) * camAlpha;
      this.camera.lookAt(-1.1, 1.45, -15);
      this.animateExplorer(dt, false);
      return;
    }

    // Smooth third-person follow camera with trauma shake & speed FOV
    const targetCamX = this.player.x * 0.62;
    const targetCamY = 3.8 + this.player.y * 0.42;
    const targetCamZ = this.playerZ + 7.2;

    const camAlpha = 1 - Math.exp(-10 * dt);
    this.camera.position.x += (targetCamX - this.camera.position.x) * camAlpha;
    this.camera.position.y += (targetCamY - this.camera.position.y) * camAlpha;
    this.camera.position.z = targetCamZ;

    this.trauma = Math.max(0, this.trauma - dt * 1.9);
    const shake = this.trauma * this.trauma;
    const shakeX = (Math.random() - 0.5) * 0.45 * shake;
    const shakeY = (Math.random() - 0.5) * 0.35 * shake;

    this.camera.lookAt(this.player.x * 0.45 + shakeX, 1.35 + this.player.y * 0.3 + shakeY, this.playerZ - 12);

    const speedRatio = Math.min(1, this.distance / 1400);
    const targetFov = 58 + speedRatio * 9 + (this.player.abilityActiveTimer > 0 ? 5 : 0);
    if (Math.abs(targetFov - this.currentFov) > 0.1) {
      this.currentFov = THREE.MathUtils.damp(this.currentFov, targetFov, 6, dt);
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    // Keep directional sun shadow frustum centered on player
    this.sunLight.position.set(this.player.x + 16, 28, this.playerZ + 12);
    this.sunLight.target.position.set(this.player.x, 0, this.playerZ - 12);
    this.sunLight.target.updateMatrixWorld();
  }

  private finishRun(victory: boolean) {
    if (this.missionCoinAccum > 0) {
      this.callbacks.onMissionIncrement({ coins: this.missionCoinAccum });
      this.missionCoinAccum = 0;
    }
    if (this.missionDistAccum >= 1) {
      this.callbacks.onMissionIncrement({ distance: Math.floor(this.missionDistAccum) });
      this.missionDistAccum = 0;
    }

    audioEngine.playGameOver();
    this.setGameState('gameover');

    const finalScore = Math.round(this.score);
    const finalDist = Math.round(this.distance);
    const bestScore = Math.max(this.saveData.bestScore, finalScore);

    let newBiomeUnlocked: BiomeId | null = null;
    for (const id of ['sunken-temple', 'underground-city', 'lost-world'] as BiomeId[]) {
      if (finalDist >= BIOMES[id].unlockDistance && !this.saveData.unlockedBiomes.includes(id)) {
        newBiomeUnlocked = id;
      }
    }

    this.callbacks.onGameOver({
      victory,
      score: finalScore,
      bestScore,
      distance: finalDist,
      coinsCollected: this.runCoins,
      relicsCollected: this.runRelics,
      bossesCleared: this.bossesCleared,
      secretRoomsFound: this.secretRoomsFound,
      newBiomeUnlocked,
      revivedUsed: this.revivedUsed,
    });
  }

  private emitHud() {
    // Pick first uncompleted mission for compact in-run tracker
    const activeMission =
      MISSIONS.find(
        (m) => (this.saveData.missionProgress[m.id] ?? 0) < m.target
      ) ?? MISSIONS[0];
    const activeChapter = getMysteryChapter(this.saveData.activeMysteryId);

    this.callbacks.onHudUpdate({
      score: Math.round(this.score),
      distance: Math.round(this.distance),
      runCoins: this.runCoins,
      runRelics: this.runRelics,
      combo: this.combo,
      hearts: this.player.hearts,
      maxHearts: this.player.maxHearts,
      shieldActive: this.player.shieldActive,
      magnetRemaining: Math.round(this.player.magnetTimer),
      multiplierRemaining: Math.round(this.player.multiplierTimer),
      abilityCharge: Math.round(this.player.abilityCharge),
      abilityActive: this.player.abilityActiveTimer > 0,
      biomeId: this.currentBiome,
      biomeName: BIOMES[this.currentBiome].name,
      inSecretRoom: this.player.secretRoomTimer > 0,
      bossActive: this.bossActive,
      bossHp: this.bossHp,
      bossMaxHp: this.bossMaxHp,
      bossTelegraphLane: this.bossTelegraphLane,
      activeMissionTitle: activeMission.title,
      activeMissionCurrent: Math.round(this.saveData.missionProgress[activeMission.id] ?? 0),
      activeMissionTarget: activeMission.target,
      speed: Math.round(computeRunSpeed(this.distance)),
      mysteryId: activeChapter.id,
      mysteryTitle: activeChapter.title,
      mysterySequence: activeChapter.sequence,
      mysteryStepIndex: this.mysteryStepIndex,
      mysteryBannerText: this.mysteryBannerText,
    });
  }

  private frameCount = 0;

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = typeof gl.fenceSync === 'function' ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
    gl.flush();
    const startPoll = performance.now();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (state === gl.UNSIGNALED && performance.now() - startPoll < 200) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(() => {
          if (!this.disposed) requestAnimationFrame(cb);
        }, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private loop = () => {
    if (this.disposed) return;

    const now = performance.now();
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
    this.elapsed += dt;

    if (this.gameState === 'playing') {
      this.updatePlaying(dt);
      this.updateAtmosphere(dt);
      this.updateParticles(dt);
      this.hudEmitAccum += dt;
      if (this.hudEmitAccum >= 0.1) {
        this.hudEmitAccum = 0;
        this.emitHud();
      }
    } else if (this.gameState === 'title') {
      this.updateAtmosphere(dt);
      this.updateParticles(dt);
    }

    this.updateCamera(dt);
    this.renderer.render(this.scene, this.camera);
    this.frameCount += 1;
    this.renderer.domElement.dataset.frames = String(this.frameCount);

    if (this.isSoftwareGl) {
      this.afterDraw(this.loop);
    } else {
      this.frameId = requestAnimationFrame(this.loop);
    }
  };

  private handleResize = () => {
    if (this.disposed) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.renderer.render(this.scene, this.camera);
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    audioEngine.stopAmbientPulse();

    this.resizeObserver?.disconnect();
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    document.removeEventListener('visibilitychange', this.onVisibilityChange);

    const dom = this.renderer.domElement;
    dom.removeEventListener('touchstart', this.onTouchStart);
    dom.removeEventListener('touchmove', this.onTouchMove);

    this.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        if (Array.isArray(mesh.material)) mesh.material.forEach((m) => m.dispose());
        else mesh.material?.dispose();
      }
    });
    this.renderer.dispose();
    if (dom.parentNode === this.container) {
      this.container.removeChild(dom);
    }
  }
}
