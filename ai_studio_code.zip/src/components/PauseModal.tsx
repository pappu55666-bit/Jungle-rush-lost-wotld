import React from 'react';
import { Home, Play, RotateCcw, Settings } from 'lucide-react';

interface PauseModalProps {
  distance: number;
  score: number;
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onReturnTitle: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  distance,
  score,
  onResume,
  onRestart,
  onOpenSettings,
  onReturnTitle,
}) => {
  return (
    <div className="fixed inset-0 z-30 bg-black/60 flex items-center justify-center p-4">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="pause-title"
        className="stone-panel rounded-2xl w-full max-w-sm p-6 text-center"
      >
        <h2 id="pause-title" className="font-display font-bold text-2xl text-[#f7cf73] tracking-wider">
          EXPEDITION PAUSED
        </h2>
        <p className="text-sm text-[#c4cfc6] mt-1">Take a breath beneath the jungle canopy.</p>

        <div className="grid grid-cols-2 gap-3 my-5">
          <div className="stone-hud rounded-xl p-3">
            <div className="text-[11px] uppercase tracking-wider text-[#9eb0a5]">Distance</div>
            <div className="font-display font-bold text-xl tabular-nums text-[#7ef7cb]">
              {distance}m
            </div>
          </div>
          <div className="stone-hud rounded-xl p-3">
            <div className="text-[11px] uppercase tracking-wider text-[#9eb0a5]">Score</div>
            <div className="font-display font-bold text-xl tabular-nums text-[#f5efe0]">
              {score.toLocaleString()}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onResume}
            className="gold-cta rounded-xl py-3 font-display font-extrabold text-base tracking-wider flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            RESUME RUN
          </button>

          <button
            type="button"
            onClick={onRestart}
            className="stone-hud rounded-xl py-2.5 font-semibold text-sm text-[#f5efe0] hover:border-[#f0c05a] flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-[#f0c05a]" />
            Restart Expedition
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={onOpenSettings}
              className="stone-hud rounded-xl py-2.5 font-semibold text-sm text-[#dfd3b8] hover:border-[#f0c05a] flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Settings className="w-4 h-4" />
              Settings
            </button>
            <button
              type="button"
              onClick={onReturnTitle}
              className="stone-hud rounded-xl py-2.5 font-semibold text-sm text-[#dfd3b8] hover:border-[#f0c05a] flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Home className="w-4 h-4" />
              Title
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
