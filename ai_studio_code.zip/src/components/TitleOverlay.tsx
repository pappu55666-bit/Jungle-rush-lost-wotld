import React from 'react';
import {
  Compass,
  Crown,
  Gift,
  Map as MapIcon,
  Play,
  Settings,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { BIOMES, CHARACTERS, MISSIONS } from '../game/catalog';
import type { SaveData } from '../game/types';

export type MetaModalTab =
  | 'characters'
  | 'levels'
  | 'missions'
  | 'mysteries'
  | 'rewards'
  | 'settings'
  | null;

interface TitleOverlayProps {
  save: SaveData;
  onStart: () => void;
  onOpenModal: (tab: Exclude<MetaModalTab, null>) => void;
  onToggleMute: () => void;
}

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  save,
  onStart,
  onOpenModal,
  onToggleMute,
}) => {
  const activeChar = CHARACTERS[save.selectedCharacter];
  const activeBiome = BIOMES[save.selectedStartBiome];
  const claimableCount = MISSIONS.filter(
    (m) => (save.missionProgress[m.id] ?? 0) >= m.target && !save.claimedMissions.includes(m.id)
  ).length;

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4 sm:p-7">
      {/* Top Bar: Vault Currency + Mute/Settings */}
      <div className="flex items-start justify-between gap-3">
        <div className="stone-hud rounded-xl px-3.5 py-2 flex items-center gap-4 pointer-events-auto">
          <div className="flex items-center gap-1.5" aria-label="Total coins">
            <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
              <circle cx="12" cy="12" r="10" fill="#d99b26" stroke="#3b2606" strokeWidth="2" />
              <circle cx="12" cy="12" r="6" fill="#ffdf70" />
            </svg>
            <span className="font-bold text-base tabular-nums text-[#ffdf70]">
              {save.totalCoins.toLocaleString()}
            </span>
          </div>
          <div className="w-px h-4 bg-[#d4a853]/30" />
          <div className="flex items-center gap-1.5" aria-label="Total relics">
            <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
              <polygon
                points="12,2 20,10 12,22 4,10"
                fill="#2df2a6"
                stroke="#0c3d29"
                strokeWidth="2"
              />
            </svg>
            <span className="font-bold text-base tabular-nums text-[#7ef7cb]">
              {save.totalRelics}
            </span>
          </div>
          {save.bestScore > 0 && (
            <>
              <div className="hidden sm:block w-px h-4 bg-[#d4a853]/30" />
              <div className="hidden sm:flex items-center gap-1.5 text-xs text-[#dfd3b8]">
                <Crown className="w-3.5 h-3.5 text-[#f0c05a]" />
                <span className="uppercase tracking-wider">Best</span>
                <span className="font-bold tabular-nums text-[#f5efe0]">
                  {save.bestScore.toLocaleString()}
                </span>
              </div>
            </>
          )}
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onToggleMute();
            }}
            aria-label={save.settings.soundEnabled ? 'Mute sound' : 'Unmute sound'}
            className="stone-hud w-10 h-10 rounded-xl flex items-center justify-center text-[#f5efe0] hover:border-[#f0c05a] transition-colors cursor-pointer"
          >
            {save.settings.soundEnabled ? (
              <Volume2 className="w-5 h-5 text-[#f0c05a]" />
            ) : (
              <VolumeX className="w-5 h-5 text-[#9ea8a0]" />
            )}
          </button>
          <button
            type="button"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenModal('settings');
            }}
            aria-label="Open settings"
            className="stone-hud w-10 h-10 rounded-xl flex items-center justify-center text-[#f5efe0] hover:border-[#f0c05a] transition-colors cursor-pointer"
          >
            <Settings className="w-5 h-5 text-[#dfd3b8]" />
          </button>
        </div>
      </div>

      {/* Left-Aligned Title Lockup & Action Stack leaving center-right 3D vista open */}
      <div className="my-auto max-w-md pointer-events-auto">
        <div className="mb-5">
          <svg
            viewBox="0 0 420 132"
            className="w-full max-w-[360px] sm:max-w-[410px] drop-shadow-[0_10px_22px_rgba(0,0,0,0.8)]"
            role="img"
            aria-label="Jungle Rush: Lost World"
          >
            {/* Carved stone crest backdrop */}
            <path
              d="M14,22 L42,6 L378,6 L406,22 L396,108 L368,124 L52,124 L24,108 Z"
              fill="rgba(14, 25, 19, 0.88)"
              stroke="#d4a853"
              strokeWidth="2.5"
            />
            <path
              d="M24,28 L46,14 L374,14 L396,28 L388,102 L364,116 L56,116 L32,102 Z"
              fill="none"
              stroke="rgba(62, 240, 180, 0.35)"
              strokeWidth="1.2"
            />
            {/* Sun relic diamond */}
            <polygon points="210,8 220,18 210,28 200,18" fill="#2df2a6" stroke="#0c3d29" strokeWidth="1.5" />
            <text
              x="210"
              y="68"
              textAnchor="middle"
              fill="#f7cf73"
              fontFamily="Cinzel, Georgia, serif"
              fontWeight="800"
              fontSize="40"
              letterSpacing="3"
            >
              JUNGLE RUSH
            </text>
            <text
              x="210"
              y="100"
              textAnchor="middle"
              fill="#86f5d0"
              fontFamily="Plus Jakarta Sans, sans-serif"
              fontWeight="700"
              fontSize="18"
              letterSpacing="7"
            >
              LOST WORLD
            </text>
          </svg>
        </div>

        <div className="flex flex-wrap items-center gap-3 mb-4">
          <button
            type="button"
            data-start="true"
            onClick={onStart}
            className="gold-cta rounded-xl px-7 py-3.5 font-display font-extrabold text-lg tracking-wider flex items-center gap-2.5 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-current" />
            START EXPEDITION
          </button>

          <button
            type="button"
            onClick={() => onOpenModal('levels')}
            className="stone-hud rounded-xl px-4 py-3.5 text-sm font-semibold text-[#f5efe0] hover:border-[#f0c05a] flex items-center gap-2 cursor-pointer"
          >
            <MapIcon className="w-4 h-4 text-[#7ef7cb]" />
            <span>{activeBiome.name}</span>
          </button>
        </div>

        {/* Compact Menu Grid */}
        <div className="grid grid-cols-3 gap-2.5 max-w-[360px]">
          <button
            type="button"
            onClick={() => onOpenModal('characters')}
            className="stone-hud rounded-xl px-3 py-2.5 text-left hover:border-[#f0c05a] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-[#b7c4ba]">
              <Compass className="w-3.5 h-3.5 text-[#f0c05a]" />
              Hero
            </div>
            <div className="font-bold text-sm text-[#f5efe0] truncate mt-0.5">{activeChar.name}</div>
          </button>

          <button
            type="button"
            onClick={() => onOpenModal('mysteries')}
            className="stone-hud rounded-xl px-3 py-2.5 text-left hover:border-[#f0c05a] transition-colors relative cursor-pointer"
          >
            <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-[#b7c4ba]">
              <Crown className="w-3.5 h-3.5 text-[#7ef7cb]" />
              Mysteries
            </div>
            <div className="font-bold text-sm text-[#f5efe0] mt-0.5">
              {claimableCount > 0 ? `${claimableCount} Ready` : `${save.solvedMysteries.length}/4 Solved`}
            </div>
          </button>

          <button
            type="button"
            onClick={() => onOpenModal('rewards')}
            className="stone-hud rounded-xl px-3 py-2.5 text-left hover:border-[#f0c05a] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-[#b7c4ba]">
              <Gift className="w-3.5 h-3.5 text-[#ffcf5c]" />
              Vault
            </div>
            <div className="font-bold text-sm text-[#f5efe0] mt-0.5">+100 Bonus</div>
          </button>
        </div>
      </div>

      {/* Single flat bottom control-hint line */}
      <div className="text-center text-xs sm:text-sm text-[#d9d2bf] tracking-wide text-stroke-dark">
        Swipe or A/D Move · W/Space Jump · S Slide · E Ability · Esc Pause
      </div>
    </div>
  );
};
