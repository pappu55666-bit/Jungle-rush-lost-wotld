import React, { useState } from 'react';
import {
  BookOpen,
  Check,
  Compass,
  Crown,
  Gift,
  Lock,
  Map as MapIcon,
  Settings,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';
import { BIOMES, BIOME_ORDER, CHARACTERS, CHARACTER_ORDER, MISSIONS } from '../game/catalog';
import { ADMOB_CONFIG } from '../game/monetization';
import {
  MYSTERY_CHAPTERS,
  RUNE_META,
  RUNE_ORDER,
  isMysteryUnlocked,
} from '../game/mysteries';
import { DAILY_REWARDED_AD_CAP, REWARDED_AD_COIN_BONUS, canWatchRewardedAd } from '../game/rules';
import type { BiomeId, CharacterId, GraphicsPreset, RuneSymbolId, SaveData } from '../game/types';
import type { MetaModalTab } from './TitleOverlay';

interface MetaModalsProps {
  activeTab: Exclude<MetaModalTab, null>;
  save: SaveData;
  todayKey: string;
  onClose: () => void;
  onSwitchTab: (tab: Exclude<MetaModalTab, null>) => void;
  onSelectOrUnlockChar: (id: CharacterId) => void;
  onSelectOrUnlockCostume: (charId: CharacterId, costumeId: string) => void;
  onSelectBiome: (id: BiomeId) => void;
  onClaimMission: (missionId: string) => void;
  onSelectMystery: (chapterId: string) => void;
  onDecipherLore: (chapterId: string, attempt: RuneSymbolId[]) => boolean;
  onWatchRewardedAd: (onTick: (sec: number) => void) => Promise<void>;
  onUpdateSettings: (partial: Partial<SaveData['settings']>) => void;
}

export const MetaModals: React.FC<MetaModalsProps> = ({
  activeTab,
  save,
  todayKey,
  onClose,
  onSwitchTab,
  onSelectOrUnlockChar,
  onSelectOrUnlockCostume,
  onSelectBiome,
  onClaimMission,
  onSelectMystery,
  onDecipherLore,
  onWatchRewardedAd,
  onUpdateSettings,
}) => {
  const [adSec, setAdSec] = useState<number | null>(null);
  const [showApkGuide, setShowApkGuide] = useState(false);
  const [cipherAttempt, setCipherAttempt] = useState<Record<string, RuneSymbolId[]>>({});
  const [cipherStatus, setCipherStatus] = useState<Record<string, string>>({});

  const adsRemaining =
    DAILY_REWARDED_AD_CAP - (save.lastAdDay === todayKey ? save.rewardedAdsToday : 0);

  const handleAd = async () => {
    setAdSec(3);
    await onWatchRewardedAd((s) => setAdSec(s > 0 ? s : null));
    setAdSec(null);
  };

  const handleGlyphTap = (chapterId: string, runeId: RuneSymbolId, targetLen: number) => {
    const prev = cipherAttempt[chapterId] ?? [];
    const next = [...prev, runeId].slice(0, targetLen);
    setCipherAttempt((cur) => ({ ...cur, [chapterId]: next }));
    if (next.length === targetLen) {
      const ok = onDecipherLore(chapterId, next);
      if (ok) {
        setCipherStatus((s) => ({ ...s, [chapterId]: 'Tablet Deciphered! Bonus Coins Granted.' }));
      } else {
        setCipherStatus((s) => ({
          ...s,
          [chapterId]: 'Sequence mismatch — study the riddle and try again.',
        }));
        setCipherAttempt((cur) => ({ ...cur, [chapterId]: [] }));
      }
    } else {
      setCipherStatus((s) => ({ ...s, [chapterId]: '' }));
    }
  };

  return (
    <div className="fixed inset-0 z-40 bg-black/72 flex items-center justify-center p-3 sm:p-6">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Expedition Hub"
        className="stone-panel rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden"
      >
        {/* Header Tabs */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-[#d4a853]/25">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {(
              [
                ['mysteries', 'Mysteries', BookOpen],
                ['missions', 'Quests', Crown],
                ['characters', 'Heroes', Compass],
                ['levels', 'Worlds', MapIcon],
                ['rewards', 'Vault', Gift],
                ['settings', 'Settings', Settings],
              ] as const
            ).map(([tabId, label, Icon]) => (
              <button
                key={tabId}
                type="button"
                onClick={() => onSwitchTab(tabId)}
                className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-colors ${
                  activeTab === tabId
                    ? 'bg-[#d99b26] text-[#161108]'
                    : 'text-[#d9d2bf] hover:bg-[#1e3327]'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 ml-2 shrink-0">
            <span className="hidden sm:inline font-bold text-sm tabular-nums whitespace-nowrap text-[#ffdf70]">
              {save.totalCoins.toLocaleString()} Coins
            </span>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close dialog"
              className="stone-hud w-9 h-9 rounded-lg flex items-center justify-center shrink-0 text-[#f5efe0] hover:border-[#f0c05a] cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          {activeTab === 'characters' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {CHARACTER_ORDER.map((charId) => {
                const char = CHARACTERS[charId];
                const unlocked = save.unlockedCharacters.includes(charId);
                const selected = save.selectedCharacter === charId;
                const activeCostumeId = save.selectedCostumes[charId] ?? char.costumes[0].id;

                return (
                  <div
                    key={charId}
                    className={`stone-hud rounded-xl p-4 flex flex-col justify-between ${
                      selected ? 'border-[#f0c05a]' : ''
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-display font-bold text-lg text-[#f7cf73]">
                            {char.name}
                          </h3>
                          <p className="text-xs text-[#86f5d0] uppercase tracking-wider">
                            {char.title}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onSelectOrUnlockChar(charId)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                            selected
                              ? 'bg-[#2df2a6] text-[#092116]'
                              : unlocked
                              ? 'bg-[#263d30] text-[#f5efe0] hover:bg-[#335241]'
                              : save.totalCoins >= char.unlockCost
                              ? 'gold-cta'
                              : 'bg-[#1c2620] text-[#808f85] cursor-not-allowed'
                          }`}
                        >
                          {selected
                            ? 'Selected'
                            : unlocked
                            ? 'Select'
                            : `Unlock (${char.unlockCost})`}
                        </button>
                      </div>

                      <div className="mt-3 text-xs text-[#d6dfd8] bg-[#0b1610]/70 rounded-lg p-2.5">
                        <span className="font-bold text-[#ffcf5c]">
                          Ability — {char.abilityName}:{' '}
                        </span>
                        {char.abilityDesc}
                      </div>
                    </div>

                    {/* Costumes */}
                    <div className="mt-3 pt-3 border-t border-[#d4a853]/20">
                      <div className="text-[11px] uppercase tracking-wider text-[#9eb0a5] mb-2">
                        Costumes
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {char.costumes.map((cos) => {
                          const cosUnlocked = save.unlockedCostumes.includes(cos.id);
                          const cosSelected = activeCostumeId === cos.id;
                          return (
                            <button
                              key={cos.id}
                              type="button"
                              disabled={!unlocked}
                              onClick={() => onSelectOrUnlockCostume(charId, cos.id)}
                              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 border cursor-pointer ${
                                cosSelected
                                  ? 'border-[#f7cf73] bg-[#2a3b2e] text-[#f7cf73]'
                                  : 'border-[#33473a] bg-[#132119] text-[#c7d1ca]'
                              } ${!unlocked ? 'opacity-45 cursor-not-allowed' : ''}`}
                            >
                              <span
                                className="w-3 h-3 rounded-full inline-block border border-white/30"
                                style={{ backgroundColor: `#${cos.primaryColor.toString(16).padStart(6, '0')}` }}
                              />
                              <span>{cos.name}</span>
                              {!cosUnlocked && <span className="text-[#ffcf5c]">({cos.price})</span>}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'levels' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {BIOME_ORDER.map((id) => {
                const biome = BIOMES[id];
                const unlocked = save.unlockedBiomes.includes(id);
                const selected = save.selectedStartBiome === id;
                return (
                  <div
                    key={id}
                    className={`stone-hud rounded-xl p-4 flex flex-col justify-between ${
                      selected ? 'border-[#f0c05a]' : ''
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="font-display font-bold text-lg text-[#f7cf73]">
                          {biome.name}
                        </h3>
                        {unlocked ? (
                          <span className="text-xs font-bold text-[#7ef7cb] flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Unlocked
                          </span>
                        ) : (
                          <span className="text-xs font-semibold text-[#9eb0a5] flex items-center gap-1">
                            <Lock className="w-3.5 h-3.5" /> {biome.unlockDistance}m
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#c7d1ca] mt-1">{biome.subtitle}</p>
                    </div>

                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span
                          className="w-5 h-5 rounded border border-white/20"
                          style={{ backgroundColor: `#${biome.groundColor.toString(16).padStart(6, '0')}` }}
                        />
                        <span
                          className="w-5 h-5 rounded border border-white/20"
                          style={{ backgroundColor: `#${biome.accentColor.toString(16).padStart(6, '0')}` }}
                        />
                      </div>
                      <button
                        type="button"
                        disabled={!unlocked}
                        onClick={() => onSelectBiome(id)}
                        className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                          selected
                            ? 'bg-[#2df2a6] text-[#092116]'
                            : unlocked
                            ? 'gold-cta'
                            : 'bg-[#1c2620] text-[#808f85] cursor-not-allowed'
                        }`}
                      >
                        {selected ? 'Active Start' : unlocked ? 'Set Start World' : `Reach ${biome.unlockDistance}m`}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'mysteries' && (
            <div className="space-y-4">
              <div className="stone-hud rounded-xl p-3.5 text-xs sm:text-sm text-[#c7d1ca]">
                <span className="font-bold text-[#f7cf73]">Ancient Mystery Missions: </span>
                Collect floating Rune Tablets during your run in the exact riddle order to solve
                chapters, unlock new worlds, and uncover Lost World lore. Decipher the tablet below
                for extra relic coins!
              </div>

              {MYSTERY_CHAPTERS.map((ch) => {
                const unlocked = isMysteryUnlocked(save, ch.id);
                const solvedInRun = save.solvedMysteries.includes(ch.id);
                const decipheredInCodex = save.decipheredLoreIds.includes(ch.id);
                const active = save.activeMysteryId === ch.id;
                const attempt = cipherAttempt[ch.id] ?? [];

                return (
                  <div
                    key={ch.id}
                    className={`stone-hud rounded-xl p-4 space-y-3 ${
                      active ? 'border-[#f0c05a]' : ''
                    } ${!unlocked ? 'opacity-65' : ''}`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded bg-[#1d3326] text-[#7ef7cb]">
                            Chapter {ch.chapterNumber} · {ch.difficultyLabel}
                          </span>
                          {solvedInRun && (
                            <span className="text-[11px] font-bold text-[#2df2a6] flex items-center gap-1">
                              <Check className="w-3.5 h-3.5" /> Run Solved
                            </span>
                          )}
                        </div>
                        <h3 className="font-display font-bold text-lg text-[#f7cf73] mt-1">
                          {ch.title}
                        </h3>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-[#ffdf70]">
                          +{ch.rewardCoins} Coins · +{ch.rewardRelics} Relics
                          {ch.unlocksBiome ? ` · Unlocks ${BIOMES[ch.unlocksBiome].name}` : ''}
                        </span>
                        <button
                          type="button"
                          disabled={!unlocked}
                          onClick={() => onSelectMystery(ch.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                            active
                              ? 'bg-[#2df2a6] text-[#092116]'
                              : unlocked
                              ? 'gold-cta'
                              : 'bg-[#1c2620] text-[#808f85] cursor-not-allowed'
                          }`}
                        >
                          {!unlocked ? (
                            <span className="flex items-center gap-1">
                              <Lock className="w-3 h-3" /> Locked
                            </span>
                          ) : active ? (
                            'Active Hunt'
                          ) : (
                            'Track in Run'
                          )}
                        </button>
                      </div>
                    </div>

                    <p className="text-xs sm:text-sm text-[#e5dcc5] bg-[#0b1610]/70 rounded-lg p-2.5 border border-[#d4a853]/15">
                      <span className="font-bold text-[#7ef7cb]">Riddle Clue: </span>
                      {ch.riddleClue}
                    </p>

                    {/* Interactive Codex Cipher Decipher Mini-Puzzle */}
                    {unlocked && (
                      <div className="bg-[#0e1b14] rounded-xl p-3 border border-[#d4a853]/20">
                        {decipheredInCodex ? (
                          <div>
                            <div className="text-xs font-bold text-[#2df2a6] flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5" />
                              {ch.loreTitle} (Deciphered)
                            </div>
                            <p className="text-xs text-[#c7d1ca] mt-1 leading-relaxed">
                              {ch.loreText}
                            </p>
                          </div>
                        ) : (
                          <div>
                            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                              <span className="text-xs font-semibold text-[#ffcf5c]">
                                Codex Decipher Challenge — Tap {ch.sequence.length} glyphs matching the riddle:
                              </span>
                              <div className="flex items-center gap-1">
                                {ch.sequence.map((_, idx) => {
                                  const chosen = attempt[idx];
                                  return (
                                    <span
                                      key={idx}
                                      className="w-6 h-6 rounded border border-[#d4a853]/40 bg-[#14241b] flex items-center justify-center text-xs font-bold"
                                      style={{
                                        color: chosen ? RUNE_META[chosen].cssColor : '#6e7f74',
                                      }}
                                    >
                                      {chosen ? RUNE_META[chosen].glyph : '?'}
                                    </span>
                                  );
                                })}
                              </div>
                            </div>

                            <div className="flex flex-wrap items-center gap-2">
                              {RUNE_ORDER.map((rId) => {
                                const meta = RUNE_META[rId];
                                return (
                                  <button
                                    key={rId}
                                    type="button"
                                    onClick={() => handleGlyphTap(ch.id, rId, ch.sequence.length)}
                                    className="stone-hud rounded-lg px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 hover:border-[#f0c05a] cursor-pointer"
                                    style={{ color: meta.cssColor }}
                                  >
                                    <span className="text-sm">{meta.glyph}</span>
                                    <span>{meta.name}</span>
                                  </button>
                                );
                              })}
                              {attempt.length > 0 && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setCipherAttempt((cur) => ({ ...cur, [ch.id]: [] }))
                                  }
                                  className="text-xs text-[#9eb0a5] hover:text-[#f5efe0] px-2 cursor-pointer"
                                >
                                  Clear
                                </button>
                              )}
                            </div>

                            {cipherStatus[ch.id] && (
                              <div className="text-xs font-semibold text-[#ffcf5c] mt-2">
                                {cipherStatus[ch.id]}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'missions' && (
            <div className="flex flex-col gap-3">
              {MISSIONS.map((m) => {
                const progress = Math.min(m.target, save.missionProgress[m.id] ?? 0);
                const claimed = save.claimedMissions.includes(m.id);
                const complete = progress >= m.target;
                const pct = Math.round((progress / m.target) * 100);
                return (
                  <div
                    key={m.id}
                    className="stone-hud rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] uppercase tracking-widest font-bold px-2 py-0.5 rounded bg-[#1d3326] text-[#86f5d0]">
                          {m.category}
                        </span>
                        <h4 className="font-semibold text-sm text-[#f5efe0]">{m.title}</h4>
                      </div>
                      <div className="mt-2 flex items-center gap-3">
                        <div className="flex-1 h-2 bg-[#14221a] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#2df2a6]"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="text-xs font-bold tabular-nums text-[#c4cfc6]">
                          {progress} / {m.target}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={!complete || claimed}
                      onClick={() => onClaimMission(m.id)}
                      className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer ${
                        claimed
                          ? 'bg-[#1c2620] text-[#7ef7cb]'
                          : complete
                          ? 'gold-cta'
                          : 'bg-[#1a2920] text-[#8ea195] cursor-not-allowed'
                      }`}
                    >
                      {claimed ? 'Claimed' : complete ? `Claim +${m.rewardCoins}` : `Reward: ${m.rewardCoins}`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'rewards' && (
            <div className="space-y-4">
              <div className="stone-hud rounded-xl p-4">
                <h3 className="font-display font-bold text-lg text-[#f7cf73]">
                  Fair Player-First Treasure Vault
                </h3>
                <p className="text-sm text-[#c7d1ca] mt-1">
                  Jungle Rush: Lost World never interrupts gameplay with forced interstitials.
                  Optionally watch a short rewarded ad preview to earn bonus coins for unlocking
                  explorers and costumes.
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 bg-[#0c1711] rounded-xl p-4 border border-[#d4a853]/25">
                  <div>
                    <div className="font-bold text-base text-[#ffdf70]">
                      +{REWARDED_AD_COIN_BONUS} Ancient Coins
                    </div>
                    <div className="text-xs text-[#9eb0a5]">
                      Daily fair limit: {Math.max(0, adsRemaining)} of {DAILY_REWARDED_AD_CAP} remaining · AdMob Mode: {ADMOB_CONFIG.mode}
                    </div>
                  </div>
                  {adSec !== null ? (
                    <span className="text-sm font-bold text-[#7ef7cb]">
                      Rewarding in {adSec}s...
                    </span>
                  ) : (
                    <button
                      type="button"
                      disabled={!canWatchRewardedAd(save, todayKey)}
                      onClick={handleAd}
                      className="gold-cta rounded-xl px-5 py-2.5 text-sm font-extrabold cursor-pointer disabled:opacity-45"
                    >
                      Watch Optional Ad
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="stone-hud rounded-xl p-3.5 flex items-center justify-between cursor-pointer">
                  <span className="font-semibold text-sm">Sound Effects</span>
                  <input
                    type="checkbox"
                    checked={save.settings.soundEnabled}
                    onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                    className="w-5 h-5 accent-[#d99b26]"
                  />
                </label>

                <label className="stone-hud rounded-xl p-3.5 flex items-center justify-between cursor-pointer">
                  <span className="font-semibold text-sm">Jungle Percussion</span>
                  <input
                    type="checkbox"
                    checked={save.settings.musicEnabled}
                    onChange={(e) => onUpdateSettings({ musicEnabled: e.target.checked })}
                    className="w-5 h-5 accent-[#d99b26]"
                  />
                </label>

                <label className="stone-hud rounded-xl p-3.5 flex items-center justify-between cursor-pointer">
                  <span className="font-semibold text-sm">On-Screen Touch Buttons</span>
                  <input
                    type="checkbox"
                    checked={save.settings.showTouchControls}
                    onChange={(e) => onUpdateSettings({ showTouchControls: e.target.checked })}
                    className="w-5 h-5 accent-[#d99b26]"
                  />
                </label>

                <div className="stone-hud rounded-xl p-3.5 flex items-center justify-between gap-3">
                  <span className="font-semibold text-sm">Master Volume</span>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={save.settings.soundVolume}
                    onChange={(e) => onUpdateSettings({ soundVolume: Number(e.target.value) })}
                    className="w-28 accent-[#d99b26]"
                  />
                </div>
              </div>

              <div className="stone-hud rounded-xl p-4">
                <div className="font-semibold text-sm mb-2.5">
                  Android Graphics Quality Preset
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      ['budget', 'Budget Android', '1x DPR · No Shadows'],
                      ['balanced', 'Balanced', '1.5x DPR · Soft Shadows'],
                      ['high', 'High Quality', '2x DPR · Full Shadows'],
                    ] as [GraphicsPreset, string, string][]
                  ).map(([preset, title, desc]) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => onUpdateSettings({ graphicsPreset: preset })}
                      className={`p-2.5 rounded-xl text-left border cursor-pointer ${
                        save.settings.graphicsPreset === preset
                          ? 'border-[#f7cf73] bg-[#24382b]'
                          : 'border-[#2f4236] bg-[#101c15]'
                      }`}
                    >
                      <div className="font-bold text-xs text-[#f5efe0]">{title}</div>
                      <div className="text-[11px] text-[#9eb0a5] mt-0.5">{desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Android APK Export Guide */}
              <div className="stone-hud rounded-xl p-4">
                <button
                  type="button"
                  onClick={() => setShowApkGuide((v) => !v)}
                  className="w-full flex items-center justify-between font-semibold text-sm text-[#7ef7cb] cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4" />
                    Export Working Android APK (Capacitor + AdMob)
                  </span>
                  <span>{showApkGuide ? 'Hide' : 'View Steps'}</span>
                </button>
                {showApkGuide && (
                  <pre className="mt-3 text-xs text-[#d6dfd8] bg-[#09120d] p-3 rounded-lg overflow-x-auto leading-relaxed">
{`1. npm install && npm run build
2. npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor-community/admob
3. npx cap init "Jungle Rush: Lost World" "com.junglerush.lostworld" --web-dir=dist
4. npx cap add android && npx cap sync android
5. npx cap open android  # Or build APK via CLI:
   cd android && ./gradlew assembleRelease`}
                  </pre>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
