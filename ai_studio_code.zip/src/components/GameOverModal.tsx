import React, { useState } from 'react';
import { Gift, Home, Play, Sparkles } from 'lucide-react';
import { BIOMES } from '../game/catalog';
import { REWARDED_AD_COIN_BONUS } from '../game/rules';
import type { RunOutcomeSnapshot } from '../game/types';

interface GameOverModalProps {
  outcome: RunOutcomeSnapshot;
  canWatchAd: boolean;
  onRetry: () => void;
  onReturnTitle: () => void;
  onWatchRewardedRevive: (onTick: (sec: number) => void) => Promise<void>;
  onWatchRewardedCoins: (onTick: (sec: number) => void) => Promise<void>;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  outcome,
  canWatchAd,
  onRetry,
  onReturnTitle,
  onWatchRewardedRevive,
  onWatchRewardedCoins,
}) => {
  const [adCountdown, setAdCountdown] = useState<number | null>(null);
  const [bonusClaimed, setBonusClaimed] = useState(false);

  const handleReviveAd = async () => {
    setAdCountdown(3);
    await onWatchRewardedRevive((s) => setAdCountdown(s > 0 ? s : null));
    setAdCountdown(null);
  };

  const handleBonusAd = async () => {
    setAdCountdown(3);
    await onWatchRewardedCoins((s) => setAdCountdown(s > 0 ? s : null));
    setAdCountdown(null);
    setBonusClaimed(true);
  };

  return (
    <div className="fixed inset-0 z-30 bg-black/68 flex items-center justify-center p-4">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="gameover-title"
        className="stone-panel rounded-2xl w-full max-w-md p-6 text-center"
      >
        <h2
          id="gameover-title"
          className="font-display font-extrabold text-2xl sm:text-3xl text-[#f7cf73] tracking-wider"
        >
          {outcome.victory ? 'TEMPLE CLEARED!' : 'EXPEDITION ENDED'}
        </h2>
        <p className="text-sm text-[#c4cfc6] mt-1">
          {outcome.newBiomeUnlocked
            ? `Unlocked New World: ${BIOMES[outcome.newBiomeUnlocked].name}!`
            : `Reached ${outcome.distance}m through the Lost World`}
        </p>

        {/* Stat Tiles */}
        <div className="grid grid-cols-3 gap-2.5 my-5">
          <div className="stone-hud rounded-xl p-3">
            <div className="text-[11px] uppercase tracking-wider text-[#9eb0a5]">Score</div>
            <div className="font-display font-bold text-lg tabular-nums text-[#f5efe0]">
              {outcome.score.toLocaleString()}
            </div>
            <div className="text-[11px] text-[#f0c05a] tabular-nums">
              Best {outcome.bestScore.toLocaleString()}
            </div>
          </div>

          <div className="stone-hud rounded-xl p-3">
            <div className="text-[11px] uppercase tracking-wider text-[#9eb0a5]">Coins</div>
            <div className="font-display font-bold text-lg tabular-nums text-[#ffdf70]">
              +{outcome.coinsCollected}
            </div>
            <div className="text-[11px] text-[#b8c4bc] tabular-nums">
              {outcome.distance}m Run
            </div>
          </div>

          <div className="stone-hud rounded-xl p-3">
            <div className="text-[11px] uppercase tracking-wider text-[#9eb0a5]">Relics</div>
            <div className="font-display font-bold text-lg tabular-nums text-[#7ef7cb]">
              +{outcome.relicsCollected}
            </div>
            <div className="text-[11px] text-[#b8c4bc] tabular-nums">
              {outcome.secretRoomsFound} Vaults
            </div>
          </div>
        </div>

        {/* Fair Player-Initiated Rewarded Ad Option */}
        {adCountdown !== null ? (
          <div className="stone-hud rounded-xl p-3.5 mb-4 text-sm font-semibold text-[#7ef7cb]">
            Rewarded Preview Active · Granting reward in {adCountdown}s...
          </div>
        ) : (
          canWatchAd && (
            <div className="flex flex-col gap-2 mb-4">
              {!outcome.revivedUsed && (
                <button
                  type="button"
                  onClick={handleReviveAd}
                  className="stone-hud rounded-xl py-2.5 px-4 text-sm font-bold text-[#7ef7cb] hover:border-[#7ef7cb] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  Optional Ad: Revive with Jade Shield
                </button>
              )}
              {!bonusClaimed && (
                <button
                  type="button"
                  onClick={handleBonusAd}
                  className="stone-hud rounded-xl py-2.5 px-4 text-sm font-bold text-[#ffdf70] hover:border-[#f0c05a] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Gift className="w-4 h-4" />
                  Optional Ad: +{REWARDED_AD_COIN_BONUS} Bonus Coins
                </button>
              )}
            </div>
          )
        )}

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onReturnTitle}
            className="stone-hud flex-1 rounded-xl py-3 font-semibold text-sm text-[#dfd3b8] hover:border-[#f0c05a] flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            Menu
          </button>

          <button
            type="button"
            data-start="true"
            onClick={onRetry}
            className="gold-cta flex-[1.6] rounded-xl py-3 font-display font-extrabold text-base tracking-wider flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            RUN AGAIN
          </button>
        </div>
      </div>
    </div>
  );
};
