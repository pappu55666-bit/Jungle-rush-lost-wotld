import React from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Pause, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { RUNE_META } from '../game/mysteries';
import type { RunHudSnapshot } from '../game/types';

interface GameHudProps {
  hud: RunHudSnapshot;
  soundEnabled: boolean;
  showTouchControls: boolean;
  abilityName: string;
  onMoveLeft: () => void;
  onMoveRight: () => void;
  onJump: () => void;
  onSlide: () => void;
  onAbility: () => void;
  onPause: () => void;
  onToggleMute: () => void;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  soundEnabled,
  showTouchControls,
  abilityName,
  onMoveLeft,
  onMoveRight,
  onJump,
  onSlide,
  onAbility,
  onPause,
  onToggleMute,
}) => {
  const missionPct = Math.min(
    100,
    Math.round((hud.activeMissionCurrent / Math.max(1, hud.activeMissionTarget)) * 100)
  );

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-3 sm:p-5">
      {/* Top Perimeter Clusters (>= 85% Viewport Unobstructed) */}
      <div className="flex items-start justify-between gap-2">
        {/* Top-Left: Vitality Sockets + Score & Coins */}
        <div className="flex flex-col gap-2">
          <div className="stone-hud rounded-xl px-3 py-2 flex items-center gap-3">
            {/* Heart Sockets */}
            <div className="flex items-center gap-1" aria-label={`Hearts ${hud.hearts} of ${hud.maxHearts}`}>
              {Array.from({ length: hud.maxHearts }).map((_, idx) => {
                const full = idx < hud.hearts;
                return (
                  <svg key={idx} viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
                    <path
                      d="M12 21s-7.5-4.7-9.6-9.1C.8 8.4 2.8 4.5 6.6 4.5c2.1 0 4 1.1 5.4 2.9 1.4-1.8 3.3-2.9 5.4-2.9 3.8 0 5.8 3.9 4.2 7.4C19.5 16.3 12 21 12 21z"
                      fill={full ? '#ef5350' : '#26332c'}
                      stroke="#111b15"
                      strokeWidth="2"
                    />
                  </svg>
                );
              })}
              {hud.shieldActive && (
                <span className="ml-1 text-[11px] font-bold uppercase tracking-wider text-[#3ef0b4]">
                  Shield
                </span>
              )}
            </div>

            <div className="w-px h-5 bg-[#d4a853]/30" />

            {/* Score */}
            <div className="flex flex-col leading-none">
              <span className="text-[10px] uppercase tracking-widest text-[#b8c4bc]">Score</span>
              <span className="font-display font-bold text-lg sm:text-xl tabular-nums text-[#f5efe0]">
                {hud.score.toLocaleString()}
              </span>
            </div>

            <div className="w-px h-5 bg-[#d4a853]/30" />

            {/* Run Coins & Relics */}
            <div className="flex items-center gap-2.5">
              <div className="flex items-center gap-1">
                <svg viewBox="0 0 24 24" className="w-4 h-4" aria-hidden="true">
                  <circle cx="12" cy="12" r="9" fill="#ffcf40" stroke="#473005" strokeWidth="2" />
                </svg>
                <span className="font-bold text-sm sm:text-base tabular-nums text-[#ffdf70]">
                  {hud.runCoins}
                </span>
              </div>
              {hud.runRelics > 0 && (
                <div className="flex items-center gap-1">
                  <svg viewBox="0 0 24 24" className="w-4 h-4" aria-hidden="true">
                    <polygon points="12,2 20,10 12,22 4,10" fill="#2df2a6" />
                  </svg>
                  <span className="font-bold text-sm tabular-nums text-[#7ef7cb]">
                    {hud.runRelics}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Active Power-up Timers (only when active) */}
          {(hud.magnetRemaining > 0 || hud.multiplierRemaining > 0 || hud.combo >= 5) && (
            <div className="flex items-center gap-2 text-xs font-bold">
              {hud.combo >= 5 && (
                <span className="stone-hud rounded-lg px-2.5 py-1 text-[#ffcf5c] tabular-nums">
                  {hud.combo}x Combo
                </span>
              )}
              {hud.magnetRemaining > 0 && (
                <span className="stone-hud rounded-lg px-2.5 py-1 text-[#66ccff] tabular-nums">
                  Magnet {hud.magnetRemaining}s
                </span>
              )}
              {hud.multiplierRemaining > 0 && (
                <span className="stone-hud rounded-lg px-2.5 py-1 text-[#f09eff] tabular-nums">
                  2x Coins {hud.multiplierRemaining}s
                </span>
              )}
            </div>
          )}
        </div>

        {/* Top-Center: Distance + Biome / Active Mystery Cipher / Boss Telegraph */}
        <div className="hidden md:flex flex-col items-center gap-1.5">
          <div className="stone-hud rounded-xl px-4 py-1.5 flex items-center gap-3">
            <span className="font-display font-bold text-base tabular-nums text-[#f7cf73]">
              {hud.distance}m
            </span>
            <span className="text-xs uppercase tracking-widest text-[#9fc7b5]">
              {hud.inSecretRoom ? 'Hidden Treasure Room' : hud.biomeName}
            </span>
          </div>

          {/* Active Ancient Mystery Cipher Strip */}
          <div
            className="stone-hud rounded-lg px-3 py-1 flex items-center gap-2 text-xs"
            aria-label={`Mystery cipher ${hud.mysteryTitle}`}
          >
            <span className="text-[#c7d1ca] font-semibold truncate max-w-[160px]">
              {hud.mysteryTitle}
            </span>
            <div className="flex items-center gap-1">
              {hud.mysterySequence.map((runeId, idx) => {
                const meta = RUNE_META[runeId];
                const solved = idx < hud.mysteryStepIndex;
                const current = idx === hud.mysteryStepIndex;
                return (
                  <span
                    key={`${runeId}-${idx}`}
                    title={meta.name}
                    className={`w-5 h-5 rounded flex items-center justify-center text-xs font-bold border ${
                      solved
                        ? 'bg-[#1a3d2d] border-[#2df2a6] text-[#2df2a6]'
                        : current
                        ? 'bg-[#2a2414] border-[#ffcf40]'
                        : 'bg-[#101c15] border-[#2f4236] opacity-55'
                    }`}
                    style={{ color: solved ? '#2df2a6' : meta.cssColor }}
                  >
                    {meta.glyph}
                  </span>
                );
              })}
            </div>
          </div>

          {hud.bossActive && (
            <div className="stone-hud rounded-lg px-3 py-1 text-xs font-bold text-[#ff885c] uppercase tracking-wider">
              Stone Sentinel Ambush · {hud.bossHp}/{hud.bossMaxHp} Strikes Left
              {hud.bossTelegraphLane !== null &&
                ` · Lane ${hud.bossTelegraphLane === -1 ? 'Left' : hud.bossTelegraphLane === 0 ? 'Center' : 'Right'} Incoming!`}
            </div>
          )}

          {hud.mysteryBannerText && (
            <div className="stone-hud rounded-lg px-3.5 py-1 text-xs font-bold text-[#ffdf70] tracking-wide">
              {hud.mysteryBannerText}
            </div>
          )}
        </div>

        {/* Top-Right: Compact Mission + Utility Square Icon Buttons */}
        <div className="flex items-start gap-2">
          <div className="hidden sm:flex flex-col stone-hud rounded-xl px-3 py-1.5 max-w-[190px]">
            <div className="flex items-center justify-between gap-2 text-[11px] text-[#b7c4ba]">
              <span className="truncate">{hud.activeMissionTitle}</span>
              <span className="tabular-nums font-bold text-[#7ef7cb]">{missionPct}%</span>
            </div>
            <div className="w-full h-1.5 bg-[#1a2b22] rounded-full overflow-hidden mt-1">
              <div
                className="h-full bg-[#2df2a6] transition-all duration-200"
                style={{ width: `${missionPct}%` }}
              />
            </div>
          </div>

          <button
            type="button"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onToggleMute();
            }}
            aria-label={soundEnabled ? 'Mute audio' : 'Unmute audio'}
            className="pointer-events-auto stone-hud w-10 h-10 rounded-xl flex items-center justify-center hover:border-[#f0c05a] cursor-pointer"
          >
            {soundEnabled ? (
              <Volume2 className="w-5 h-5 text-[#f0c05a]" />
            ) : (
              <VolumeX className="w-5 h-5 text-[#9ea8a0]" />
            )}
          </button>

          <button
            type="button"
            tabIndex={-1}
            onClick={(e) => {
              e.currentTarget.blur();
              onPause();
            }}
            aria-label="Pause game"
            className="pointer-events-auto stone-hud w-10 h-10 rounded-xl flex items-center justify-center hover:border-[#f0c05a] cursor-pointer"
          >
            <Pause className="w-5 h-5 text-[#f5efe0]" />
          </button>
        </div>
      </div>

      {/* Mobile compact distance, cipher & boss banner */}
      <div className="md:hidden self-center mt-1 flex flex-col items-center gap-1">
        <div className="stone-hud rounded-lg px-3 py-1 text-xs font-bold tabular-nums text-[#f7cf73] flex items-center gap-2">
          <span>
            {hud.distance}m · {hud.inSecretRoom ? 'Treasure Vault' : hud.biomeName}
          </span>
          <span className="flex items-center gap-0.5">
            {hud.mysterySequence.map((runeId, idx) => {
              const meta = RUNE_META[runeId];
              const solved = idx < hud.mysteryStepIndex;
              return (
                <span
                  key={`${runeId}-${idx}`}
                  style={{ color: solved ? '#2df2a6' : meta.cssColor }}
                  className={idx === hud.mysteryStepIndex ? 'underline font-extrabold' : 'opacity-70'}
                >
                  {meta.glyph}
                </span>
              );
            })}
          </span>
        </div>
        {hud.mysteryBannerText && (
          <div className="stone-hud rounded-lg px-2.5 py-0.5 text-[11px] font-bold text-[#ffdf70]">
            {hud.mysteryBannerText}
          </div>
        )}
        {hud.bossActive && (
          <div className="stone-hud rounded-lg px-2.5 py-0.5 text-[11px] font-bold text-[#ff885c]">
            Boss Sentinel ({hud.bossHp}/{hud.bossMaxHp})
          </div>
        )}
      </div>

      {/* Bottom Corners: Ergonomic Android Touch Controls + Ability Charge */}
      <div className="mt-auto flex items-end justify-between gap-2">
        {/* Bottom-Left: Special Ability stacked cleanly above Lane Arrows on mobile */}
        <div className="flex flex-col items-start sm:flex-row sm:items-end gap-2 pointer-events-auto">
          <button
            type="button"
            tabIndex={-1}
            disabled={hud.abilityCharge < 100}
            onPointerDown={(e) => {
              e.preventDefault();
              onAbility();
            }}
            aria-label={`Activate ${abilityName}`}
            className={`rounded-2xl px-3.5 py-2 flex items-center gap-2 font-bold text-xs sm:text-sm whitespace-nowrap transition-transform active:scale-95 cursor-pointer sm:order-2 ${
              hud.abilityCharge >= 100
                ? 'gold-cta'
                : 'stone-hud text-[#9ea8a0] opacity-85 cursor-not-allowed'
            }`}
          >
            <Sparkles className="w-4 h-4 shrink-0" />
            <div className="text-left leading-tight">
              <div>{abilityName}</div>
              <div className="text-[10px] tabular-nums opacity-85">
                {hud.abilityCharge >= 100 ? 'READY [E]' : `${hud.abilityCharge}%`}
              </div>
            </div>
          </button>

          {showTouchControls && (
            <div className="flex items-center gap-2 sm:order-1">
              <button
                type="button"
                tabIndex={-1}
                onPointerDown={(e) => {
                  e.preventDefault();
                  onMoveLeft();
                }}
                aria-label="Move Left"
                className="stone-hud w-13 h-13 rounded-2xl flex items-center justify-center active:scale-95 text-[#f5efe0] cursor-pointer"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <button
                type="button"
                tabIndex={-1}
                onPointerDown={(e) => {
                  e.preventDefault();
                  onMoveRight();
                }}
                aria-label="Move Right"
                className="stone-hud w-13 h-13 rounded-2xl flex items-center justify-center active:scale-95 text-[#f5efe0] cursor-pointer"
              >
                <ArrowRight className="w-6 h-6" />
              </button>
            </div>
          )}
        </div>

        {/* Bottom-Right: Jump & Slide Touch Buttons */}
        {showTouchControls && (
          <div className="flex items-end gap-2.5 pointer-events-auto">
            <button
              type="button"
              tabIndex={-1}
              onPointerDown={(e) => {
                e.preventDefault();
                onSlide();
              }}
              aria-label="Slide"
              className="stone-hud w-14 h-14 rounded-2xl flex flex-col items-center justify-center active:scale-95 text-[#7ef7cb] cursor-pointer"
            >
              <ArrowDown className="w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Slide</span>
            </button>

            <button
              type="button"
              tabIndex={-1}
              onPointerDown={(e) => {
                e.preventDefault();
                onJump();
              }}
              aria-label="Jump"
              className="gold-cta w-16 h-16 rounded-2xl flex flex-col items-center justify-center cursor-pointer"
            >
              <ArrowUp className="w-6 h-6" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider">Jump</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
