const config = {
  appId: 'com.junglerush.lostworld',
  appName: 'Jungle Rush: Lost World',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  plugins: {
    AdMob: {
      // Replace with your Google AdMob App ID before Play Store release
      androidAppId: 'ca-app-pub-3940256099942544~3347511713',
    },
  },
};

export default config;
